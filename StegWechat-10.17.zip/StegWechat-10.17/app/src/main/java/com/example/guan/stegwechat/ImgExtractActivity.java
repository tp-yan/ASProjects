package com.example.guan.stegwechat;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ru.bartwell.exfilepicker.ExFilePicker;
import ru.bartwell.exfilepicker.data.ExFilePickerResult;

public class ImgExtractActivity extends PickImageActivity {
    private static final String TAG = "ImgExtractActivity";
    public static final int REQUEST_SHOW_IMAGE = 2;
    private ProgressDialog progressDialog;

    protected String hint_1 = "请添加提取图片！";
    protected String hint_2 = "请选中提取图片！";

    private String startDirectory = null;   // 记录上一次访问的文件目录路径
    private static final int EX_FILE_PICKER_RESULT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img_extract);

        getWidgets();
        startDirectory = Environment.getExternalStorageDirectory().getPath() + "/tencent/MicroMsg/WeiXin/";
        Log.d(TAG, "startDirectory: " + startDirectory);
    }

    private void getWidgets() {
        addImg = (Button) findViewById(R.id.add_file);
        selectAll = (Button) findViewById(R.id.select_all);
        delete = (Button) findViewById(R.id.delete);
        nextStep = (Button) findViewById(R.id.next_btn);
        imgListView = (ListView) findViewById(R.id.img_list);

        imgListAdapter = new ArrayAdapter<>(ImgExtractActivity.this, android.R.layout.simple_list_item_multiple_choice, imgListData);
        imgListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        imgListView.setAdapter(imgListAdapter);
        imgListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showImgDialog(imgPaths.get(position), imgListData.get(position));
                return true;    // 返回true不会触发点击事件
            }
        });

        addImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImg();
            }
        });
        selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAllFile();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFileFromList();
            }
        });

        nextStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                extractImg();
            }
        });
    }

    // 提取图像
    private void extractImg() {
        ArrayList<String> selectImgPath = checkImgList(hint_1,hint_2);
        if (selectImgPath != null && selectImgPath.size() > 0){
            PrivateHash privateHash = (PrivateHash) getApplication();
            String embedkey  = privateHash.get_embed_key();
            if (embedkey.equals(""))
            {
                Toast.makeText(this, "缺失密钥，请填写！", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ImgExtractActivity.this, Config_Setting.class);
                startActivity(intent);
                return;
            }else{
                StringBuilder allImgPath = new StringBuilder();
                for (int i = 0 ; i < selectImgPath.size()-1; i++){
                    allImgPath.append(selectImgPath.get(i));
                    allImgPath.append("||");
                }
                allImgPath.append(selectImgPath.get(selectImgPath.size()-1));

                new ExtractThreadTask().execute(allImgPath.toString(),embedkey);
            }
        }
    }

    // 打开WX存放接收图片的目录，选择图像
    private void chooseImg() {
        ExFilePicker exFilePicker = new ExFilePicker();
        exFilePicker.setCanChooseOnlyOneItem(true); // 单选
        exFilePicker.setQuitButtonEnabled(true);
        exFilePicker.setStartDirectory(startDirectory);
        exFilePicker.setChoiceType(ExFilePicker.ChoiceType.FILES);
        exFilePicker.start(ImgExtractActivity.this, EX_FILE_PICKER_RESULT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case EX_FILE_PICKER_RESULT:
                if (resultCode == RESULT_OK) {
                    ExFilePickerResult result = ExFilePickerResult.getFromIntent(data);
                    if (result != null && result.getCount() > 0) {
                        List<String> filenames = result.getNames(); // 所选文件名
                        String file_dir = result.getPath();         // 文件所在目录
                        startDirectory = file_dir;
                        String filePath = file_dir + filenames.get(0);
                        Log.d(TAG, "file_dir: "+file_dir);
                        Log.d(TAG, "filename: "+filenames.get(0));
                        Log.d(TAG, "filePath: "+filePath);
                        // 规定每次只选择一个文件，故若已存在则不再添加
                        if (imgPaths.contains(filePath)) {
                            return;
                        }
                        imgPaths.add(filePath);
                        imgListData.add(filenames.get(0));  // 只保存文件名
                        updateListView();   // 更新显示列表
                    }
                    break;
                }

            case REQUEST_SHOW_IMAGE:
                finish();
                break;
        }
    }

    // 只将最新添加的文件勾选
    private void updateListView(){
        SparseBooleanArray checkedItems = imgListView.getCheckedItemPositions();
        int k = imgListData.size() - 1;
        checkedItems.put(k, true);
        imgListAdapter.notifyDataSetChanged();
    }

    // 开启子线程来完成提取
    private class ExtractThreadTask extends AsyncTask<String, Integer, byte[]> {

        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ImgExtractActivity.this);
            progressDialog.setTitle("系统提示");
            progressDialog.setMessage("正在提取，请等待...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        protected byte[] doInBackground(String... params) {    //byte
            int count = params.length;
            String AllPathh = params[0];
            int seedh = Integer.parseInt(params[1]);
            PrivateHash privateHash = (PrivateHash) getApplication();
            String password = privateHash.get_password();
            byte[] flag = StegoAlgorithm.algorithmtype(AllPathh, password ,seedh); //byte
//            String process_time = Double.toString((System.currentTimeMillis() - begintimeh)/1000);
//            flag = flag +"||"+process_time;

            return flag;
        }

//        protected void onProgressUpdate(Integer... progress) {
//            setProgressPercent(progress[0]);
//        }

        protected void onPostExecute(final byte[] result) {
//            String[] each_file_path = result.split("\\|\\|");
//            showresult.setText("提取完成，共耗时"+each_file_path[1]+"s");
            AlertDialog.Builder builder = new AlertDialog.Builder(ImgExtractActivity.this);
            //设置对话框标题
            builder.setTitle("系统提示");
            builder.setCancelable(false);
            byte errflag=-1;
            //设置对话框内的文本
            if(errflag==result[0])
            {
                builder.setMessage("该图没有嵌入消息！");
                //设置确定按钮
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        skip();
                    }
                });
            }
            else if(result[0]==0)
            {
                builder.setMessage("存在不同任务载密图像！");
                //设置确定按钮
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        skip();
                    }
                });
            }
            else if(result[0]==-2)
            {
                builder.setMessage("本次嵌入载密图像未提供完整，请添加本次任务全部载密图像！");
                //设置确定按钮
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        skip();
                    }
                });
            }
            else
            {
                builder.setMessage("提取完成！");
                //设置确定按钮
                builder.setNegativeButton("展示秘密信息", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        byte msg_type=result[0];
                        int datalength = result.length-2;
                        byte []data = new byte[datalength];
                        System.arraycopy(result, 1, data, 0, datalength);
                        if (msg_type==1) {
                            Intent intent = new Intent(ImgExtractActivity.this, ShowText.class);
                            String text = new String(data);
                            intent.putExtra("data", text);
                            startActivity(intent);
                            finish();
                        }
                        else if(msg_type==2)
                        {
                            Intent intent = new Intent(ImgExtractActivity.this, AudioOutputActivity.class);
                            intent.putExtra("data", data);
                            startActivity(intent);
                            finish();
                        }
                        else if(msg_type==3) //图片展示
                        {
                            Intent intent = new Intent(ImgExtractActivity.this, ShowMultiImageActivity.class);
                            intent.putExtra("flag",1);  // 传入图像bytes
                            intent.putExtra("data",data);
                            startActivityForResult(intent,REQUEST_SHOW_IMAGE);
                            finish();
                        }
                        else if(msg_type==4)
                        {
                            Intent intent = new Intent(ImgExtractActivity.this, FileOutputActivity.class);
                            intent.putExtra("data", data);
                            startActivity(intent);
                            finish();
                        }
                    }
                });
            }

            //使用builder创建出对话框对象
            AlertDialog dialog = builder.create();
            //显示对话框
            dialog.show();
        }
        private void skip() {
            Intent intent2 = new Intent();
            intent2.setClass(ImgExtractActivity.this, MainInterface.class);
            startActivity(intent2);
            finish();
        }
    }
}
