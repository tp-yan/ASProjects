package com.example.guan.stegwechat.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.guan.stegwechat.AudioInputActivity;
import com.example.guan.stegwechat.FileInputActivity;
import com.example.guan.stegwechat.ImgPickActivity;
import com.example.guan.stegwechat.R;
import com.example.guan.stegwechat.Text_writeActivity;


/**
 * 需要像定义Activity一样，定义Fragment
 */
// 嵌入界面Fragment
public class EmbedFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    /**
     * 每次调用生产一个新的Fragment实例，同时还可以给Fragment传递参数，在Fragment的其他方法中可以获得该参数
     * 每次新建Fragment实例都执行完整的生命周期
     * index：当前页码,从1开始
     */
    public static EmbedFragment newInstance(int index) {
        EmbedFragment fragment = new EmbedFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // 生成 Fragment 显示的组件
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 可以根据传入的参数来加载不同的布局，实现不同的逻辑功能
        View rootView = null;
        Context context = getActivity();
        int position = getArguments().getInt(ARG_SECTION_NUMBER, 0);
        switch (position) {
            case 1: // 加载 嵌入 界面布局
                rootView = inflater.inflate(R.layout.fragment_embed, container, false);
                ImageButton txtButton = rootView.findViewById(R.id.write_text);
                ImageButton audioButton = rootView.findViewById(R.id.voice);
                ImageButton imgButton = rootView.findViewById(R.id.image);
                ImageButton fileButton = rootView.findViewById(R.id.document);
                addListener2ButtonEmbed(context, txtButton, imgButton, audioButton, fileButton);
                break;
        }
        return rootView;
    }

    // 给嵌入界面的按钮绑定事件监听器
    private void addListener2ButtonEmbed(Context context, ImageButton... btns) {
        int index = 1;
        for (ImageButton b : btns) {
            switch (index) {
                case 1:
                    b.setOnClickListener(v -> {
                        Intent intent = new Intent(context, Text_writeActivity.class);
                        startActivity(intent);

                    });
                    break;
                case 2:
                    b.setOnClickListener(v -> {
                        Intent intent = new Intent(context, ImgPickActivity.class);
                        startActivity(intent);
                    });
                    break;
                case 3:
                    b.setOnClickListener(v -> {
                        Intent intent = new Intent(context, AudioInputActivity.class);
                        startActivity(intent);
                    });
                    break;
                case 4:
                    b.setOnClickListener(v -> {
                        Intent intent = new Intent(context, FileInputActivity.class);
                        startActivity(intent);
                    });
                    break;
            }
            index++;
        }
    }
}
