package com.example.guan.stegwechat;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Arrays;
import java.util.List;

public class AudioOutputActivity extends AppCompatActivity {
    ImageView mStartPlayButton;
    private SpeexPlayer splayer = null;
    private static byte[] mPlayData;
    private static List<D000> list0;
    public  static Context mContext;
    Button finsh;
    private static int mPlaySize = -1;
    public void playIsOver() {
        if(splayer!=null){
            splayer.stopPlay();
            splayer = null;
        }
        mStartPlayButton.setImageResource(R.drawable.playblue);
    }
    public static Handler handler = new Handler() {
        // 获取录音模块获得的数据，并跳转到发送界面
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 4:
                    ((AudioOutputActivity) mContext).playIsOver();
            }
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_output);
        mStartPlayButton =  (ImageView) findViewById(R.id.playImageView);
        Intent intent = getIntent();
        byte[] audioArray = intent.getByteArrayExtra("data");
        finsh = (Button)findViewById(R.id.show_audio_finsh);
        mPlayData = audioArray;
        mContext = AudioOutputActivity.this;
        mStartPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Drawable.ConstantState  constantState = mStartPlayButton.getDrawable().getCurrent().getConstantState();
                Drawable.ConstantState constState2 = getDrawable(R.drawable.playblue).getConstantState();
                if(constantState == constState2){
                    if(splayer!=null) {
                        if (splayer.isPause()) {
                            splayer.startStopedPlay();
                            mStartPlayButton.setImageResource(R.drawable.pause2);
                        }
                    }else {
                        if (mPlayData != null) {
                            mPlaySize=mPlayData.length-20;
                            list0 = C000.ToL(mPlayData, mPlaySize);
                            SpeexPlayer.list0 = list0;
                            SpeexPlayer.startActivtiy="AudioOutputActivity";
                            splayer = new SpeexPlayer();
                            splayer.startPlay();//开始播放
                            mStartPlayButton.setImageResource(R.drawable.pause2);
                        }
                    }

                }
                else{
                    mStartPlayButton.setImageResource(R.drawable.playblue);
                    if(splayer!=null){
                        splayer.stopPlay();
                    }
                }
            }
        });
        finsh.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AudioOutputActivity.this,MainInterface.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
