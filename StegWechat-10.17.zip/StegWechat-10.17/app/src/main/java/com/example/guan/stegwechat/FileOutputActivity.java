package com.example.guan.stegwechat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputActivity extends AppCompatActivity {
    private String ZipPath = "";
    private Button nextButton;
    private TextView showPathTextView;
    private EditText extractPath;
    private Button finishButton;
    String topath = "";
    File fileh = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_output);
        nextButton = (Button)findViewById(R.id.fileOutputNextButton);
        showPathTextView = (TextView)findViewById(R.id.fileOutputTextView);
        extractPath = (EditText)findViewById(R.id.fileEditText);
        Intent intent = getIntent();
        byte[] intentData = intent.getByteArrayExtra("data");
        ZipPath = Environment.getExternalStorageDirectory().getPath() + "/Download/secret.zip";
        saveFile(ZipPath,intentData);
        fileh= new File(ZipPath);
        topath = fileh.getParent()+"/";
        finishButton = (Button)findViewById(R.id.fileOutputFinish);
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FileOutputActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        showPathTextView.setText("请输入文件提取路径");
        extractPath.setText(topath);
        extractPath.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                topath = extractPath.getText().toString();
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!fileh.exists()){
                    Toast.makeText(FileOutputActivity.this,"文件已删除，请不要重复提取",Toast.LENGTH_SHORT).show();
                }
                else {
                    uncompress uncompressh = new uncompress(ZipPath, topath);
                    uncompressh.unzip();
                    fileh.delete();
                    Toast.makeText(FileOutputActivity.this, "文件提取成功", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void openAssignFolder(String path){
        File file = new File(path);
        if(null==file || !file.exists()){
            return;
        }
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //intent.setDataAndType(Uri.fromFile(file), "file/*");
        intent.setType("*/*");
        try {
            startActivity(intent);
            //startActivity(Intent.createChooser(intent,"选择浏览工具"));
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }
    void saveFile(String filename,byte [] data) {
        if (data != null) {
            File file = new File(filename);
            if (file.exists()) {
                file.delete();
            }
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                fos.write(data, 0, data.length);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                fos.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
