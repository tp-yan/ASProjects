package com.example.guan.stegwechat;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.guan.stegwechat.adapter.TaskGroupRecyclerAdapter;
import com.example.guan.stegwechat.bean.SingleTask;

import java.io.File;
import java.util.ArrayList;
import java.util.function.Consumer;

// 提取分组界面
public class ExtractGroupActivity extends AppCompatActivity {
    private static final String TAG = "ExtractGroupActivity";
    private static final int REQUEST_SHOW_IMAGE = 2;   // 调用 ShowMultiImageActivity 的请求码

    ArrayList<SingleTask> taskList; // 封装 RecyclerView 所需显示数据
    Button extractButton;
    private int flag = -1; // 标识当前界面是 已提取(0)还是待提取(1)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extract_group);
        flag = getIntent().getIntExtra("flag", 0);
        setTitle(flag == 0 ? R.string.extracted : R.string.not_extract);

        initTaskList();

        RecyclerView recyclerView = findViewById(R.id.recyclerView_extract);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        TaskGroupRecyclerAdapter adapter = new TaskGroupRecyclerAdapter(taskList, this);
        recyclerView.setAdapter(adapter);

        extractButton = findViewById(R.id.extract_btn);
        extractButton.setOnClickListener(v -> {
            if (adapter.lastPosition >= 0) {
                Toast.makeText(ExtractGroupActivity.this, "Position:" + adapter.lastPosition, Toast.LENGTH_SHORT).show();
                extractImg(adapter.lastPosition);
            } else
                Toast.makeText(ExtractGroupActivity.this, "请选择要提取的分组！", Toast.LENGTH_SHORT).show();
        });
    }

    // 执行提取
    private void extractImg(int position) {
        // 从配置文件读取置乱密钥
        PrivateHash privateHash = (PrivateHash) getApplication();
        String embedkey  = privateHash.get_embed_key();
        if (TextUtils.isEmpty(embedkey)) {
            Toast.makeText(this, "缺失置乱密钥，请填写！", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, Config_Setting.class);
            startActivity(intent);
        } else {
            SingleTask task = taskList.get(position);
            ArrayList<String> selectImgPath = task.getImgPath();
            if (selectImgPath.size() <= 0) {
                Toast.makeText(this, "无选中的图片!", Toast.LENGTH_SHORT).show();
                return;
            }
            // 将所选图片路径拼接为一个字符串
            StringBuilder allImgPath = new StringBuilder();
            for (int i = 0; i < selectImgPath.size() - 1; i++) {
                allImgPath.append(selectImgPath.get(i));
                allImgPath.append("||");
            }
            allImgPath.append(selectImgPath.get(selectImgPath.size() - 1));
            Log.d(TAG, "extractImg: " + allImgPath);
            new ExtractThreadTask().execute(allImgPath.toString(), embedkey);
            finish();
        }
    }

    /**
     * 模拟实现 提取后移动图片的操作
     */
    private void moveImg() {

        File srcDir = Environment.getExternalStoragePublicDirectory("TestImg");
        Log.d(TAG, "srcDir: " + srcDir.getAbsolutePath());

        File destDir = getExternalFilesDir("img");
        Log.d(TAG, "destDir: " + destDir.getAbsolutePath());

        String[] fileNames = {"baohu.png", "baozheng.png", "bidian.png", "xiaoshi.png"};

        for (String fileName : fileNames) {
            Utils.copyFile(new File(srcDir, fileName), destDir.getAbsolutePath(), fileName);
            boolean r = Utils.deleteFile(srcDir.getAbsolutePath() + File.separator + fileName);
            Log.d(TAG, "delete " + fileName + " : " + r);
        }
    }

    // 此处进行分组逻辑一个任务封装为一个SingleTask
    private void initTaskList() {
        Toast.makeText(this, "数据分组 flag==" + flag, Toast.LENGTH_SHORT).show();
//        moveImg();
        File imgDir = getExternalFilesDir("img"); // Android/data/包名/files/img
        String imgRootPath = imgDir.getAbsolutePath();

        ArrayList<ArrayList<String>> imgPaths = new ArrayList<>();
        String[][] fileNames = {{"IMG_4_rc_STC.jpg","IMG_5_rc_STC.jpg","IMG_6_rc_STC.jpg"},
                {"IMG_1_rc_STC.jpg"}, {"IMG_2_rc_STC.jpg"}, {"IMG_3_rc_STC.jpg"}};
        for (int i = 0; i < fileNames.length; i++) {
            ArrayList<String> imgs = new ArrayList<>();
            String[] files = fileNames[i];
            for (String name : files) {
                imgs.add(imgRootPath + File.separator + name);
            }
            imgPaths.add(imgs);
        }
//        String[] fileNames2 = {"1familyguy.png", "2familyguy.png", "3familyguy.png", "4familyguy.png"};
//        String[] fileNames3 = {"familyguy1.png", "familyguy2.png", "familyguy3.png", "familyguy4.png"};

        taskList = new ArrayList<>();
        int counter = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < imgPaths.size(); j++) {
                SingleTask task = new SingleTask("task" + counter++, imgPaths.get(j));
                taskList.add(task);
            }
        }
        Log.d(TAG, "initTaskList: " + taskList);
    }


    // 开启子线程来完成提取
    private ProgressDialog progressDialog;

    private class ExtractThreadTask extends AsyncTask<String, Integer, byte[]> {

        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ExtractGroupActivity.this);
            progressDialog.setTitle("系统提示");
            progressDialog.setMessage("正在提取...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        protected byte[] doInBackground(String... params) {    //byte
            int count = params.length;
            String AllPathh = params[0];
            int seedh = Integer.parseInt(params[1]);
            PrivateHash privateHash = (PrivateHash) getApplication();
            String password = privateHash.get_password();
            byte[] flag = StegoAlgorithm.algorithmtype(AllPathh, password, seedh); //byte
            return flag;
        }

        protected void onPostExecute(final byte[] result) {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(ExtractGroupActivity.this);
            builder.setTitle("系统提示");
            builder.setCancelable(false);
            byte errflag = -1;
            if (errflag == result[0]) {
                builder.setMessage("该图没有嵌入消息！");
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        skip();
                    }
                });
            } else if (result[0] == 0) {
                builder.setMessage("存在不同任务载密图像！");
                builder.setPositiveButton("确定", (dialog, which) -> skip());
            } else if (result[0] == -2) {
                builder.setMessage("本次嵌入载密图像未提供完整，请添加本次任务全部载密图像！");
                builder.setPositiveButton("确定", (dialog, which) -> skip());
            } else {
                builder.setMessage("提取完成！");
                //设置确定按钮
                builder.setNegativeButton("展示秘密信息", (dialog, which) -> {
                    byte msg_type = result[0]; // 提取消息的类型
                    int datalength = result.length - 2;
                    byte[] data = new byte[datalength];
                    System.arraycopy(result, 1, data, 0, datalength);
                    Activity activity = ExtractGroupActivity.this;
                    if (msg_type == 1) {
                        Intent intent = new Intent(activity, ShowText.class);
                        String text = new String(data);
                        intent.putExtra("data", text);
                        startActivity(intent);
                        activity.finish();
                    } else if (msg_type == 2) {
                        Intent intent = new Intent(activity, AudioOutputActivity.class);
                        intent.putExtra("data", data);
                        startActivity(intent);
                        activity.finish();
                    } else if (msg_type == 3) // 图片
                    {
                        Intent intent = new Intent(activity, ShowMultiImageActivity.class);
                        intent.putExtra("flag", 1);  // 传入图像bytes
                        intent.putExtra("data", data);
                        startActivityForResult(intent, REQUEST_SHOW_IMAGE);
                    } else if (msg_type == 4) {
                        Intent intent = new Intent(activity, FileOutputActivity.class);
                        intent.putExtra("data", data);
                        startActivity(intent);
                        activity.finish();
                    }
                });
            }
            //使用builder创建出对话框对象
            AlertDialog dialog = builder.create();
            //显示对话框
            dialog.show();
        }

        // 返回主界面
        private void skip() {
            Intent intent2 = new Intent();
            intent2.setClass(ExtractGroupActivity.this, MainActivity.class);
            startActivity(intent2);
        }
    }
}
