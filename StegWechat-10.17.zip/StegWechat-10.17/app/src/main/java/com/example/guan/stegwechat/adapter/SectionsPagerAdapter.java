package com.example.guan.stegwechat.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.guan.stegwechat.main.EmbedFragment;

import com.example.guan.stegwechat.main.NewExtractFragment;

/**
 * FragmentPagerAdapter是专门给ViewPager填充数据的Adapter，由它指定ViewPager有多少页，每页加载哪个Fragment
 */
public class SectionsPagerAdapter extends FragmentPagerAdapter {
    FragmentManager fm;
    EmbedFragment embedFragment;

    NewExtractFragment newExtractFragment;

    public SectionsPagerAdapter(FragmentManager fm) {
        super(fm);
        this.fm = fm;
    }

    @Override
    public Fragment getItem(int position) {// 根据位置来决定返回什么样的Fragment
        if (position == 0) {// 加载嵌入Fragment
            if (embedFragment == null) {
                embedFragment = EmbedFragment.newInstance(position + 1);
            }
            return embedFragment;
        } else {// 加载提取Fragment
            if (newExtractFragment == null) {
                newExtractFragment = newExtractFragment.newInstance(position + 1);
            }
            return newExtractFragment; // 切换时会保留该页面的Fragment上下文环境
        }
    }

    @Override
    public int getCount() {// 该Adapter包含多少项，即ViewPager的页数
        return 2;
    }
}
