package com.example.guan.stegwechat;

import android.app.Application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.security.MessageDigest;

public class PrivateHash extends Application {
    private String password;
    private String embed_key;

    @Override
    public void onCreate() {
        password = "";
        embed_key = "";
        super.onCreate();
    }

    public static String getMD5(String str){
        String result ="";
        try{
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte [] bytes = md5.digest(str.getBytes());
            for(byte b : bytes)
            {
                String temp = Integer.toHexString(b & 0xff);
                if(temp.length() == 1)
                {
                    temp = "0" + temp;
                }
                result = result + temp;
            }
        }catch (Exception e){
            System.out.println("MD5加密出现错误");
        }
        return result;
    }
    public static String getSHA1(String str){
        String result ="";
        try{
            MessageDigest sha1 = MessageDigest.getInstance("SHA1");
            byte [] bytes = sha1.digest(str.getBytes());
            for(byte b : bytes)
            {
                String temp = Integer.toHexString(b & 0xff);
                if(temp.length() == 1)
                {
                    temp = "0" + temp;
                }
                result = result + temp;
            }
        }catch (Exception e){
            System.out.println("SHA1加密出现错误");
        }
        return result;
    }
    public static String key_file(String filePath) {
        String key_string = "";
        try {
            FileReader fr = new FileReader(filePath);
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            while(line!=null){
                key_string=key_string+line;
                line = br.readLine();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return key_string;
    }

    public static byte[] file2byte(String Path){
        try {
            FileInputStream in = new FileInputStream(new File(Path));
            //当文件没有结束时，每次读取一个字节显示
            byte[] data = new byte[in.available()];
            in.read(data);
            in.close();
            return data;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void file_embedkey(String Path){
        File embedkey_file = new File(Path);
        byte[] embedkey_decode = new byte[6];
        if (embedkey_file.exists()){
            byte[] read_embedkey = this.file2byte(Path);
            String sha1_password = this.getSHA1(this.password);
            byte [] sha1_password_byte = sha1_password.getBytes();
            for(int i=0;i<6;i++){
                embedkey_decode[i] = (byte)(read_embedkey[i]^sha1_password_byte[i]);
            }
            this.embed_key = (new String(embedkey_decode));
        }
    }

    public void put_password(String password) {
        this.password = password;
    }
    public void put_embed_key(String embed_key) {
        this.embed_key = embed_key;
    }
    public String get_password() {
        return this.password;
    }
    public String get_embed_key() {
        return this.embed_key;
    }
}
