package com.example.guan.stegwechat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;

public class MyCameraActivity extends AppCompatActivity {
    private static final String TAG = "MyCameraActivity";

    private final int REQUEST_CODE = 100;
    private int QUALITY = 60;

    /**
     * Camera类用于管理和操作camera资源，它提供了完整的相机底层接口，支持相机资源切换，
     * 设置预览、拍摄尺寸，设定光圈、曝光、聚焦等相关参数，获取预览、拍摄帧数据等功能
     * 预览≠拍摄
     */
    private Camera camera;
    private Button takePhoto;
    private CameraPreview cameraPreview; // 相机预览控件

    private byte[] jpegData;  // 保存相机拍摄的照片数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_camera);

        initViews();
    }

    private void initViews() {

        takePhoto = (Button) findViewById(R.id.take_photo);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.surface_view);
        cameraPreview = new CameraPreview(this);
        camera = cameraPreview.getCamera();
        frameLayout.addView(cameraPreview);

        // 设置自动对焦
        cameraPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camera.autoFocus(null);
            }

        });


        takePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camera = cameraPreview.getCamera();
                //得到照相机的参数
                Camera.Parameters parameters = camera.getParameters();
                //图片的格式
                parameters.setPictureFormat(ImageFormat.JPEG);
                //设置对焦模式，自动对焦
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                //对焦成功后，自动拍照
                camera.autoFocus(new Camera.AutoFocusCallback() {
                    @Override
                    public void onAutoFocus(boolean success, Camera camera) {
                        if (success) {
                            // 这个是实现相机拍照的主要方法，包含了三个回调参数。
                            // shutter是快门按下时的回调，raw是获取拍照原始数据的回调，jpeg是获取经过压缩成jpg格式的图像数据的回调。
                            camera.takePicture(null, raw, mPictureCallback);
//                            camera.stopPreview();
                        }
                    }
                });
            }
        });

    }

    // 获得没有压缩过的图片数据
    private Camera.PictureCallback raw = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera Camera) {
            Log.i(TAG, "raw：");
            if(data != null){
                Log.d(TAG, "onPictureTaken: " + data.length/ 1024 + "K");
            }
        }
    };

    // 创建jpeg图片回调数据对象：将原始图像数据以JPEG格式保存到本地
    Camera.PictureCallback mPictureCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            Log.d(TAG, "jpeg: "+ data.length / 1024 + "K");  // 350K
            int size = data.length / 1024;
            if (size > 500){
                QUALITY = 20;
            }else if (size > 300){
                QUALITY = 30;
            }else if (size > 200){
                QUALITY = 40;
            }else if (size > 100){
                QUALITY = 50;
            }

            Bitmap b = BitmapFactory.decodeByteArray(data,0,data.length);
            Log.d(TAG, "bitmap width*height: "+b.getWidth()+"*"+b.getHeight()); // 1920*1080
            ByteArrayOutputStream bos = null;
            bos = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, QUALITY, bos);  // 将图片压缩到流中
            jpegData = bos.toByteArray();
            showPreviewPic(jpegData);
            Log.d(TAG, "final jpeg: "+ jpegData.length / 1024 + "K");  // 301k --> 67k

        }
    };


    private void showPreviewPic(byte[] data){
        Intent intent = new Intent(MyCameraActivity.this,ShowMultiImageActivity.class);
        intent.putExtra("flag",3);
        intent.putExtra("data",data);
        startActivityForResult(intent,REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE){
            if (resultCode == RESULT_OK){
                int flag = data.getIntExtra("flag",-1);
                switch (flag){
                    case 1: // 重拍
                        jpegData = null;
                        camera = cameraPreview.getCamera();
                        camera.startPreview();
                        break;
                    case 2: // 完成拍照
                        Intent intent = new Intent();
                        intent.putExtra("camera_data",jpegData);
                        setResult(RESULT_OK,intent);
                        finish();
                        break;
                }
            }

        }
    }
}
