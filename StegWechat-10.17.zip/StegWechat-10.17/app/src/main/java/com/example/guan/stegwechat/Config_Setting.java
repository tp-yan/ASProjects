package com.example.guan.stegwechat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class Config_Setting extends Activity {
    SharedPreferences sharedpreferences;
    EditText embed_key_et;
    EditText stc_h_et;
    EditText payload_et;
    public static final String mypreference = "configure";
    //public static final String embedkey = "embedKey";
    public static final String stc_h = "stc_hKey";
    public static final String payload = "payloadKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.config);
        embed_key_et = (EditText) findViewById(R.id.key);
        stc_h_et = (EditText) findViewById(R.id.h);
        payload_et = (EditText) findViewById(R.id.payload_edit);
        sharedpreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        PrivateHash privateHash = (PrivateHash) getApplication();
        embed_key_et.setText(privateHash.get_embed_key());
        if (sharedpreferences.contains(stc_h)) {
            stc_h_et.setText(sharedpreferences.getString(stc_h, ""));

        }
        if (sharedpreferences.contains(payload)) {
            payload_et.setText(sharedpreferences.getString(payload, ""));
        }

    }

    public void ConfigFinsh(View view) {
        String ek = embed_key_et.getText().toString();
        String s = stc_h_et.getText().toString();
        String p = payload_et.getText().toString();
        double double_p;
        double int_s;
        if("".equals(ek))
        {
            Toast.makeText(getApplicationContext(), "请输入密钥!",
                    Toast.LENGTH_SHORT).show();
        }
        else if("".equals(p))
        {
            Toast.makeText(getApplicationContext(), "请输入负载率!",
                    Toast.LENGTH_SHORT).show();
        }
        else if("".equals(s))
        {
            Toast.makeText(getApplicationContext(), "STC编码矩阵高度!",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            try{
                if(ek.length() < 6 || ek.length() > 10){
                    Toast.makeText(getApplicationContext(), "请输入长度为6到10位的数字密钥!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            }catch (Exception e){
                Toast.makeText(getApplicationContext(), "密钥仅支持数字!",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            try{
                double_p = Double.parseDouble(p);
                if(double_p > 0.5 || double_p < 0) {
                    Toast.makeText(getApplicationContext(), "负载率范围在0到0.5之间!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            }catch(Exception e){
                Toast.makeText(getApplicationContext(), "负载率仅支持小数!",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            try{
                int_s= Integer.parseInt(s);
                if(int_s > 15 || int_s < 7) {
                    Toast.makeText(getApplicationContext(), "STC编码矩阵高度在7到15之间!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            }catch(Exception e){
                Toast.makeText(getApplicationContext(), "STC编码矩阵高度仅支持整数!",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        }
        SharedPreferences.Editor editor = sharedpreferences.edit();
        PrivateHash privateHash = (PrivateHash) getApplication();
        privateHash.put_embed_key(ek);
        File sys_file_path = getExternalFilesDir(null);
        String read_path = sys_file_path.getPath();
        String file_path_embedkey = read_path + "/embed_key.txt";
        String sha1_password = privateHash.getSHA1(privateHash.get_password());
        byte[] sha1_password_byte = sha1_password.getBytes();
        byte[] embedkey_byte = ek.getBytes();
        byte[] embedkey_code = new byte[6];
        for(int i=0;i<6;i++){
            embedkey_code[i] = (byte)(embedkey_byte[i]^sha1_password_byte[i]);
        }
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(file_path_embedkey));
            out.write(new String(embedkey_code));
            out.close();
        } catch (Exception e) {
        }
        editor.putString(stc_h, s);
        editor.putString(payload, p);
        editor.commit();
        Intent intent = new Intent(Config_Setting.this, MainInterface.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}

