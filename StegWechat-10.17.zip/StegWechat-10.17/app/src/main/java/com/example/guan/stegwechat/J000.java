package com.example.guan.stegwechat;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import android.os.Message;
/**
 * 将recorder录制的声音数据流转码，并交给writer封装 SpeexEncode类
 *
 * @author 双剑
 *
 */
public class J000 implements Runnable {
    private final Object mutex = new Object();// 信号量协调线程工作
    private S000 speex = new S000();// 创建speex实例用于调用其中的方法
    public static int encoder_packagesize = 1024;// 编码单位
    private byte[] processedData = new byte[encoder_packagesize];
    List<D000> list0 = null;

    List<ReadData> list = null;// 待处理数据队列
    private volatile boolean isRecording;// 是否录音中
    long sizecount = 0;
    long sizebefore = 0;

    public J000() {
        super();
        speex.init();
        list = Collections.synchronizedList(new LinkedList<ReadData>());
        list0 = Collections.synchronizedList(new LinkedList<D000>());
        // 用于存储压缩后的数据
    }

    public void run() {
        // 将该线程设为紧急权限
        android.os.Process
                .setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);

        int getSize = 0;
        while (this.isRecording()) {//一边录音，一般转换数据
            if (list.size() == 0) {
                // 待处理数据列表中没有数据
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                continue;// 循环等待
            }

            if (list.size() > 0) {// 有数据要处理
                synchronized (mutex) {
                    ReadData rawdata = list.remove(0);// 移除第一个数据，并返回该数据
                    getSize = speex.encode(rawdata.ready, 0, processedData,
                            rawdata.size);// 编码并返回大小
                }
                if (getSize > 0) {
                    D000 cd = new D000();
                    cd.setData(processedData);
                    cd.setSize(getSize);
                    list0.add(cd);//添加处理后的数据
                    //	SpeexPlayer.list0=list0;
                    processedData = new byte[encoder_packagesize];// 重新开辟空间
                }
            }
        }
        int bsize = 0;
        //获取数据总长度
        for (int i = 0; i < list0.size(); i++) {
            bsize += list0.get(i).getSize();

        }
        //将数据发送至主线程
        Message msg = new Message();
        msg.what = 1;
        msg.arg1 = bsize;
        byte[] data = C000.ToA(list0,bsize);//将处理后的数据合成整体，发送给activity
        msg.obj = data;
        if(data.length>1024*1024*10){
            msg.arg2 = 0;
        }else{
            msg.arg2 = 1;
        }
        AudioInputActivity.handler.sendMessage(msg);
    }

    /**
     * 将录音机传来的数据封装为ReadData类型，并将readData加入待处理队列
     *
     * @param data
     * @param size
     */
    public void putData(short[] data, int size) {
        ReadData rd = new ReadData();
        synchronized (mutex) {
            rd.size = size;
            // 将data拷贝到ready中
            System.arraycopy(data, 0, rd.ready, 0, size);
            list.add(rd);// 将rd加入待处理的队列
        }
    }

    public void setRecording(boolean isRecording) {
        synchronized (mutex) {
            this.isRecording = isRecording;
        }
    }

    public boolean isRecording() {
        synchronized (mutex) {
            return isRecording;
        }
    }

    class ReadData {
        private int size;
        private short[] ready = new short[encoder_packagesize];
    }

}
