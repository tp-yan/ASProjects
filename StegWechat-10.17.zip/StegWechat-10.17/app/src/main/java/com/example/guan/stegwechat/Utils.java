package com.example.guan.stegwechat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import me.shaohui.advancedluban.Luban;
import me.shaohui.advancedluban.OnCompressListener;
import ru.bartwell.exfilepicker.ExFilePicker;

public class Utils {
    private static final String TAG = "Utils";


    /**
     * 根据文件路径拷贝文件
     *
     * @param src      源文件
     * @param destPath 目标文件路径
     * @return boolean 成功true、失败false
     */
    public static boolean copyFile(File src, String destPath, String newFileName) {
        boolean result = false;
        if ((src == null) || (destPath == null)) {
            return result;
        }
        File dest = new File(destPath + File.separator + newFileName);
        if (dest != null && dest.exists()) {
            dest.delete(); // delete file
        }
        try {
            dest.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileChannel srcChannel = null;
        FileChannel dstChannel = null;

        try {
            srcChannel = new FileInputStream(src).getChannel();
            dstChannel = new FileOutputStream(dest).getChannel();
            srcChannel.transferTo(0, srcChannel.size(), dstChannel);
            result = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return result;
        } catch (IOException e) {
            e.printStackTrace();
            return result;
        }
        try {
            srcChannel.close();
            dstChannel.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 删除文件
     *
     * @param filePath
     * @return
     */
    public static boolean deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.isFile() && file.exists()) {
            return file.delete();
        }
        return false;
    }

    /**
     * 长按列表选项，可缩放查看图片
     *
     * @param imgPath 传入的图片路径
     * @param imgName
     */
    public static void showImgDialog(Context context, String imgPath, String imgName) {
        Intent intent = new Intent(context, ShowMultiImageActivity.class);
        Log.d(TAG, "imgPath: " + imgPath);
        intent.putExtra("imgPath", imgPath);
        intent.putExtra("flag", 0);  // 传入图像路径：载体与提取界面
        context.startActivity(intent);
    }

    /**
     * 采用双线性下采样，按指定宽高比压缩图像
     *
     * @param bitmap
     * @param scaleW
     * @param scaleH
     * @return
     */
    public static Bitmap downSample(Bitmap bitmap, float scaleW, float scaleH) {
        Matrix matrix = new Matrix();
        matrix.setScale(scaleW, scaleH);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                bitmap.getHeight(), matrix, true);
    }

    public static void compressImg(Context context, File file, OnCompressListener listener, int type) {
        if (type == 0) {// 类似微信压缩，一般400+k，1512*2016
            Luban.compress(context, file)           // 初始化Luban，并传入要压缩的图片
                    .putGear(Luban.THIRD_GEAR)      // 类似微信的压缩效果，适用于普通压缩，没有文件大小限制以及图片的宽高限制
                    .launch(listener);              // 启动压缩并设置监听
        } else if (type == 1) {// 自定义压缩
            Luban.compress(context, file)
                    .setMaxSize(400)                // 限制最终图片大小（单位：Kb）
                    .setMaxHeight(4032)             // 限制图片高度
                    .setMaxWidth(3024)              // 限制图片宽度
                    .setCompressFormat(Bitmap.CompressFormat.JPEG)            // 自定义压缩图片格式，目前只支持：JPEG和WEBP，因为png不支持压缩图片品质
                    .putGear(Luban.THIRD_GEAR)     // 使用 CUSTOM_GEAR 压缩模式
                    .launch(listener);
        }
    }

    // 根据 图片绝对路径加载本地图片
    public static Bitmap getLocalBitmap(String url) {
        try {
            FileInputStream inputStream = new FileInputStream(url);
            return BitmapFactory.decodeStream(inputStream); //把输入流转化为Bitmap图片
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 从路径中提取图片的名字
    public static String getImgName(String imgPath) {
        StringBuilder sb = new StringBuilder();
        int j = 0;
        for (int i = imgPath.length() - 1; i >= 0; i--) {
            if (imgPath.charAt(i) == '/') {
                j = i;
                break;
            }
        }
        for (int i = j + 1; i < imgPath.length(); i++) {
            sb.append(imgPath.charAt(i));
        }
        return sb.toString();
    }

    // 将ArrayList对象转为byte[]，对象的持久化就是这样做的：将对象变为byte[]后可恢复
    public static byte[] arrayList2Byte(ArrayList<byte[]> list) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(list);
            objectOutputStream.flush();

            byte[] data = byteArrayOutputStream.toByteArray();
            objectOutputStream.close();
            byteArrayOutputStream.close();
            return data;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 将byte[]转为ArrayList对象
    public static ArrayList<byte[]> byte2ArrayList(byte[] bytes) {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            ArrayList<byte[]> list = (ArrayList<byte[]>) objectInputStream.readObject();

            objectInputStream.close();
            inputStream.close();
            return list;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static byte[] File2Byte(String filePath) {
        byte[] buffer = null;
        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n;
            while ((n = fis.read(b)) != -1) {
                bos.write(b, 0, n);
            }
            fis.close();
            bos.close();
            buffer = bos.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return buffer;
    }

    public static void byte2File(byte[] buf, String filePath, String fileName) {
        BufferedOutputStream bos = null;
        FileOutputStream fos = null;
        File file = null;
        try {
            File dir = new File(filePath);
            if (!dir.exists() && dir.isDirectory()) {
                dir.mkdirs();
            }
            file = new File(filePath + File.separator + fileName);
            fos = new FileOutputStream(file);
            bos = new BufferedOutputStream(fos);
            bos.write(buf);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
