package com.example.guan.stegwechat;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Text_writeActivity extends AppCompatActivity {
    Button b1, b2;
    EditText et1,et2;
    private int flag = 1;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_write);
        b1 = (Button) findViewById(R.id.text_clear);
        b2 = (Button) findViewById(R.id.text_next);
        et1 = (EditText) findViewById(R.id.textedit);
        et1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                et1.setHint(null);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = et1.getText().toString();
                byte[] data = message.getBytes();
                if("".equals(message))
                {
                    Toast.makeText(getApplicationContext(), "请输入秘密文字!",
                            Toast.LENGTH_SHORT).show();

                }
                else {
                    Intent intent = new Intent(Text_writeActivity.this, CoverSelectActivity.class);
                    intent.putExtra("data", data);
                    intent.putExtra("flag", flag);
                    startActivity(intent);
                    finish();
                }
            }

        });
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
    }
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
}
