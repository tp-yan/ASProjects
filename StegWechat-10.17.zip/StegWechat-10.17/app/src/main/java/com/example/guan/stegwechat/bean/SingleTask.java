package com.example.guan.stegwechat.bean;

import java.util.ArrayList;
import java.util.List;

// 代表一个提取任务分组，包括任务名(或id)，以及该批任务的图像路径
public class SingleTask {
    private String taskName;
    private ArrayList<String> imgPath;

    public SingleTask(String taskName, ArrayList<String> imgPath) {
        this.taskName = taskName;
        this.imgPath = imgPath;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public ArrayList<String> getImgPath() {
        return imgPath;
    }

    public void setImgPath(ArrayList<String> imgPath) {
        this.imgPath = imgPath;
    }

    @Override
    public String toString() {
        return "SingleTask{" +
                "taskName='" + taskName + '\'' +
                ", imgPath=" + imgPath +
                '}';
    }
}
