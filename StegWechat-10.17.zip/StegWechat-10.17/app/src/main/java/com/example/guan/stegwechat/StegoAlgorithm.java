package com.example.guan.stegwechat;

public class StegoAlgorithm {
    public static native String STCembed(final String PicPath, final String Apppath, byte[] data,
                                         String password, final int flag, final int seed,
                                         final double payload, final int matrixheight,
                                         int randSeed, byte[] randomKeys);

    public static native byte[] algorithmtype(final String PicPath,String password, final int seed);
    static {
        System.loadLibrary("native-lib");
        System.loadLibrary("ffmpeg");
    }
}
