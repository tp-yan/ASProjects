package com.example.guan.stegwechat.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.guan.stegwechat.ExtractGroupActivity;
import com.example.guan.stegwechat.R;

public class NewExtractFragment extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";

    public static NewExtractFragment newInstance(int index) {
        NewExtractFragment fragment = new NewExtractFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = null;
        int position = getArguments().getInt(ARG_SECTION_NUMBER, 0);
        if (position == 2) { // 加载 提取 界面布局
            rootView = inflater.inflate(R.layout.fragment_new_extract, container, false);
            TextView extractedTxt = rootView.findViewById(R.id.extracted);
            TextView notExtractTxt = rootView.findViewById(R.id.not_extract);
            extractedTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goExtractGroup(0);
                }
            });
            notExtractTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goExtractGroup(1);
                }
            });
        }
        return rootView;
    }

    private void goExtractGroup(int flag) {
        Intent intent = new Intent(getActivity(), ExtractGroupActivity.class);
        intent.putExtra("flag", flag);
        startActivity(intent);
    }
}
