package com.example.guan.stegwechat;

public class D000 {
	public static int encoder_packagesize = 1024;// ���뵥λ
	private int size;
	private byte[] data = new byte[encoder_packagesize];
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	
}
