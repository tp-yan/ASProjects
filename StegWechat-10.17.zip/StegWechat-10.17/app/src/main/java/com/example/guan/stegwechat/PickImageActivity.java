package com.example.guan.stegwechat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import me.nereo.multi_image_selector.MultiImageSelector;
import me.nereo.multi_image_selector.MultiImageSelectorActivity;
import me.shaohui.advancedluban.OnCompressListener;

public class PickImageActivity extends AppCompatActivity {
    private static final String TAG = "PickImageActivity";

    protected LinkedHashMap<String, byte[]> cameraImg = new LinkedHashMap<>();

    protected Button addImg, selectAll, delete, nextStep;
    protected ListView imgListView;

    protected ArrayAdapter<String> imgListAdapter;
    protected ArrayList<String> imgListData = new ArrayList<>();
    protected ArrayList<String> imgPaths = new ArrayList<>();

    public static final int REQUEST_STORAGE_READ_ACCESS_PERMISSION = 101;
    public static final int REQUEST_IMAGE = 2;
    public static final int COMPRESS_WECHAT = 0;
    public static final int COMPRESS_CUSTOM = 1;

    // 原始尺寸：1512*2016
    private float scaleW = 0.7f;
    private float scaleH = 0.7f;
    protected int IMG_QUALITY = 50;
    /*
     * 60:149K
     * */

    protected Boolean showCamera = false;
    protected Boolean selectAllFile = true;     // 是否已全选文件

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void showCameraImg(byte[] data) {
        Intent intent = new Intent(PickImageActivity.this, ShowMultiImageActivity.class);
        intent.putExtra("data", data);
        intent.putExtra("flag", 2);  // 传入bitmap
        startActivity(intent);
    }

    public void showImgDialog(String imgPath, String imgName) {
        Intent intent = new Intent(this, ShowMultiImageActivity.class);
        Log.d(TAG, "imgPath: " + imgPath);
        intent.putExtra("imgPath", imgPath);
        intent.putExtra("flag", 0);  // 传入图像路径：载体与提取界面
        startActivity(intent);
    }

    public void pickImg() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN // Permission was added in API Level 16
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE,
                    getString(R.string.mis_permission_rationale),
                    REQUEST_STORAGE_READ_ACCESS_PERMISSION);
        } else {// 已授权
            MultiImageSelector.create(PickImageActivity.this)
                    .showCamera(showCamera)  // 是否显示相机. 默认为显示
                    .count(1000)      // 最大选择图片数量, 默认为9. 只有在选择模式为多选时有效
                    //.single()       // 单选模式
                    .multi()          // 多选模式, 默认模式;
                    .origin(imgPaths) // 默认已选择图片. 只有在选择模式为多选时有效
                    .start(PickImageActivity.this, REQUEST_IMAGE);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_IMAGE:
                if (resultCode == RESULT_OK) {
                    // 获取返回的图片列表
                    imgPaths = data.getStringArrayListExtra(MultiImageSelectorActivity.EXTRA_RESULT);
                    filterNonJPG(imgPaths);
                    imgListData.clear();
                    if (this instanceof ImgPickActivity) {
                        checkFromCamera();
                    }
                    updateListView(imgPaths);
                    appendCameraImg2ImgListData();
                    imgListAdapter.notifyDataSetChanged();
                }
                break;
        }
    }

    // 过滤非 .jpg .jpeg 图片格式
    private void filterNonJPG(ArrayList<String> mImgPaths) {
        ArrayList<String> nonJPE = new ArrayList<>();
        for (String path : mImgPaths) {
            if (!path.toLowerCase().endsWith(".jpg") && !path.toLowerCase().endsWith(".jpeg")) {
                nonJPE.add(path);
            }
        }
        if (nonJPE.size() > 0) {
            mImgPaths.removeAll(nonJPE);
            StringBuilder sb = new StringBuilder();
            for (String path : nonJPE) {
                sb.append(extractNameFromPath(path) + "\n");
            }
            Toast.makeText(this, "无法选择非JPG格式图像：\n" + sb.toString(), Toast.LENGTH_LONG).show();
            Log.d(TAG, "filterNonJPG: " + nonJPE);
        }
    }

    private String extractNameFromPath(String path) {
        int index = path.lastIndexOf("/");
        if (index > 0) {
            return path.substring(index + 1);
        }
        return path;
    }

    // 将拍的照片追加到列表imgListData后面
    protected void appendCameraImg2ImgListData() {
        if (this instanceof ImgPickActivity) {
            for (String key : cameraImg.keySet()) {
                addItem2ImgListData(key);
            }
        }
        imgListAdapter.notifyDataSetChanged();
    }

    // 检查是否由相机拍摄的照片，若是则从imgPaths移除并压缩
    protected void checkFromCamera() {
        for (int i = imgPaths.size() - 1; i >= 0; i--) {
            if (imgPaths.get(i).contains("IMG_SKL_SGH_")) {// from camera
                final String imgPath = imgPaths.remove(i);
                final String name = Utils.getImgName(imgPath);
                // 压缩完成后的监听器
                OnCompressListener listener = new MyOnCompressListener(name, imgPath);
                File file = new File(imgPath);
                Log.d(TAG, "checkFromCamera: " + imgPath);
//                Bitmap bitmap = Utils.getLocalBitmap(imgPath);
//                // 4032*3024
//                Log.d(TAG, "原始图像尺寸： " + bitmap.getWidth() + "*" + bitmap.getHeight());
                // 进行异步图片压缩，可选择压缩方式
                Utils.compressImg(this, file, listener, COMPRESS_WECHAT);
            }
        }
    }

    class MyOnCompressListener implements OnCompressListener {
        String name, imgPath;

        public MyOnCompressListener(String name, String imgPath) {
            this.name = name;
            this.imgPath = imgPath;
        }

        @Override
        public void onStart() {

        }

        @Override
        public void onSuccess(File file) {
            Bitmap bitmap = Utils.getLocalBitmap(file.getAbsolutePath());
            // 压缩图像尺寸
            Log.d(TAG, "压缩前尺寸: " + bitmap.getWidth() + "*" + bitmap.getHeight());
            bitmap = Utils.downSample(bitmap, scaleW, scaleH);
            Log.d(TAG, "压缩后尺寸: " + bitmap.getWidth() + "*" + bitmap.getHeight());
            // 对压缩后的图像按质量因子压缩不改变尺寸
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, IMG_QUALITY, baos);
            byte[] data = baos.toByteArray();
            cameraImg.put(name, data);

            appendCameraImg2ImgListData();
            Log.d(TAG, "压缩后图像大小: " + data.length / 1024 + "K");

            File oldFile = new File(imgPath);
            if (oldFile.exists()) {
                Log.d(TAG, "delete camera file");
                oldFile.delete();
            }
            if (file.exists()) {
                Log.d(TAG, "delete compressed file");
                file.delete();   // 删除压缩时的临时文件
            }
        }

        @Override
        public void onError(Throwable e) {

        }
    }

    protected void updateListView(ArrayList<String> imgPaths) {
        for (int i = 0; i < imgPaths.size(); i++) {
            String imgPath = imgPaths.get(i);   // 绝对路径
            extractImgName(imgPath);
        }
    }

    // 从路径中提取图片的名字，并添加到imgListData中
    protected void extractImgName(String imgPath) {
        StringBuilder sb = new StringBuilder();
        int j = 0;
        for (int i = imgPath.length() - 1; i >= 0; i--) {
            if (imgPath.charAt(i) == '/') {
                j = i;
                break;
            }
        }
        for (int i = j + 1; i < imgPath.length(); i++) {
            sb.append(imgPath.charAt(i));
        }

        addItem2ImgListData(sb.toString());
    }

    // 将一张图片名字添加到 ImgListData并选中
    protected void addItem2ImgListData(String imgName) {
        if (imgListData.contains(imgName))
            return;
        imgListData.add(imgName);
        SparseBooleanArray checkedItems1 = imgListView.getCheckedItemPositions();
        int k = imgListData.size() - 1;
        checkedItems1.put(k, true);
    }

    // 全选或全不选文件
    protected void selectAllFile() {
        Boolean value;

        if (selectAllFile) {// 若原本是全选，点击后，则全不选
            selectAllFile = value = false;
        } else {
            selectAllFile = value = true;
        }
        SparseBooleanArray checkedItems = imgListView.getCheckedItemPositions();
        for (int i = 0; i < imgListData.size(); i++) {
            checkedItems.put(i, value);  // map类型的结构，key：int,value:bool。覆盖之前的值
        }
        imgListAdapter.notifyDataSetChanged();
    }

    // 从列表中删除勾选的文件
    protected void deleteFileFromList() {
        SparseBooleanArray checkedItems = imgListView.getCheckedItemPositions();
        //逆序删除 避免索引越界
        for (int i = checkedItems.size() - 1; i >= 0; i--) {
            if (checkedItems.valueAt(i)) {
                // 文件名数组与文件路径数组必须同步
                String item = imgListData.get(i);
                if (cameraImg.containsKey(item)) {
                    cameraImg.remove(item);
                } else {
                    imgPaths.remove(i);
                }
                imgListData.remove(i);
                checkedItems.delete(i);
            }
        }

        selectAllFile = false;
        imgListAdapter.notifyDataSetChanged();
    }

    protected ArrayList<String> checkImgList(String hint_1, String hint_2) {
        ArrayList<String> selectedImgPathList = null;
        if (imgListData.size() > 0) {
            SparseBooleanArray checkedArray = imgListView.getCheckedItemPositions();
            selectedImgPathList = new ArrayList<>();
            for (int i = 0; i < checkedArray.size(); i++) {
                if (checkedArray.valueAt(i)) {
                    String item = imgListData.get(i);
                    if (cameraImg.containsKey(item)) {
                        selectedImgPathList.add(item);
                    } else
                        selectedImgPathList.add(imgPaths.get(i));
                }
            }
            if (selectedImgPathList.size() > 0) {
                Log.d(TAG, "selectedImgPathList: " + selectedImgPathList);
                return selectedImgPathList;
            } else {
                Toast.makeText(this, hint_2, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, hint_1, Toast.LENGTH_SHORT).show();
        }
        return selectedImgPathList;
    }

    public void requestPermission(final String permission, String rationale, final int requestCode) {
        // 由系统决定需不需要弹出权限申请对话框：若之前用户拒绝过授权，则shouldShowRequestPermissionRationale返回true
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            new AlertDialog.Builder(this)   // 自定义权限申请对话框
                    .setTitle(R.string.mis_permission_dialog_title)
                    .setMessage(rationale)
                    .setPositiveButton(R.string.mis_permission_dialog_ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // 向Android申请权限
                            ActivityCompat.requestPermissions(PickImageActivity.this, new String[]{permission}, requestCode);
                        }
                    })
                    .setNegativeButton(R.string.mis_permission_dialog_cancel, null)
                    .create().show();
        } else {
            // app第一次请求权限时，不会展示自定义的权限对话框，执行else 块的代码
            // 直接弹出Android系统自己的权限申请对话框，在这里才是用户进行真正的授权
            ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_STORAGE_READ_ACCESS_PERMISSION:  // TP add
                // 授权之后，不做任何的操作，则需要用户再次点击“选择图片”
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImg();
                } else {
                    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                    Toast.makeText(this, "需要读写文件权限", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
