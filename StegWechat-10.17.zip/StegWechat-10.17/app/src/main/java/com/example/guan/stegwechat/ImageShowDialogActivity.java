package com.example.guan.stegwechat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class ImageShowDialogActivity extends AppCompatActivity {
    private static final String TAG = "ImageShowDialogActivity";
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_show_dialog);

        init();
    }

    private void init() {
        imageView = (ImageView) findViewById(R.id.image_view);

        Intent intent = getIntent();
        int flag = intent.getIntExtra("flag", -1);
        if (flag == -1) {
            Toast.makeText(this, "获取数据失败！", Toast.LENGTH_SHORT).show();
            finish();
        } else if (flag == 0) { // 图像路径
            String imgPath = intent.getStringExtra("imgPath");
            Bitmap bitmap = Utils.getLocalBitmap(imgPath);
            imageView.setImageBitmap(bitmap);
        } else if (flag == 1) {// 多张图像bytes
            byte[] imgBytes = intent.getByteArrayExtra("data");
            ArrayList<byte[]> imgs = Utils.byte2ArrayList(imgBytes);
            byte[] firstImg = imgs.get(0);
//            // 去除第一个byte：标志位
//            System.arraycopy(imgBytes,0,imgBytes,1,imgBytes.length-1);
            Bitmap bitmap = BitmapFactory.decodeByteArray(firstImg,0,firstImg.length);
            imageView.setImageBitmap(bitmap);
        } else if (flag == 2) {// 拍照图片bytes
            byte[] data = intent.getByteArrayExtra("data");
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
//            Log.d(TAG, "显示的尺寸：width*height "+bitmap.getWidth()+"*"+bitmap.getHeight());
            imageView.setImageBitmap(bitmap);
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
