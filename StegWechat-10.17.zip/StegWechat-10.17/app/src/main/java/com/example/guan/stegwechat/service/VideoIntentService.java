package com.example.guan.stegwechat.service;

import android.app.IntentService;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

public class VideoIntentService extends IntentService {
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private static final String TAG = "VideoIntentService";
    public static final String BROADCAST_ACTION_VIDEO_RESULT = "com.example.guan.stegwechat.VIDEO_RESULT";
    public static final String EXTRA_VIDEO_RESULT = "com.example.guan.stegwechat.VIDEO_RESULT";


    public VideoIntentService() {
        super("VideoIntentService");
    }

    // 此方法在子线程中执行
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d(TAG, "onHandleIntent: 开始密钥提取");

        long startTime = System.currentTimeMillis();
        int[] data = getRandomKey();
        if (data == null || data.length <= 0) {
            Toast.makeText(this, "提取密钥失败！", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "提取密钥失败！: ");
        }
        long endTime = System.currentTimeMillis();

        Toast.makeText(this, "getRandomKey(): 耗时：" + (endTime - startTime) / 1000, Toast.LENGTH_SHORT).show();
        Log.d(TAG, "getRandomKey(): 耗时：" + (endTime - startTime) / 1000);

        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this);
        Intent resultIntent = new Intent(BROADCAST_ACTION_VIDEO_RESULT);
        resultIntent.putExtra(EXTRA_VIDEO_RESULT, data);
        localBroadcastManager.sendBroadcast(resultIntent);
    }

    // 从视频获取密钥
    public native int[] getRandomKey();
}
