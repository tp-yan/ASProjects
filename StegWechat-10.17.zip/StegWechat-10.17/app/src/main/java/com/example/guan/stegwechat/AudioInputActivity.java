package com.example.guan.stegwechat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class AudioInputActivity extends AppCompatActivity {
    ImageButton mStartRecordButton;
    ImageButton mStartPlayButton;
    SpeexRecorder mRecorder = null;
    Thread mThread = null;
    TextView mTimeTextView;
    TextView mPlayTimeTextView;
    Timer timer ;
    MyTask task;
    Button mNextButton;
    private static byte[] mPlayData;
    public  static Context mContext;
    private static int mPlaySize = -1;
    private static List<D000> list0;
    private SpeexPlayer splayer = null;
    public static int TimerCount = 0;
    private int flag = 2;
    public static Handler handler = new Handler() {
        // 获取录音模块获得的数据，并跳转到发送界面
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    byte[] bdata = (byte[]) msg.obj;//获取字节流
                    synchronized (bdata) {
                        mPlayData = Arrays.copyOf(bdata, bdata.length);
                    }
                    mPlaySize = msg.arg1;
                    break;
                case 2:
                    break;
                case 3:
                    TimerCount++;
                    StringBuilder sb = new StringBuilder();
                    int hour = TimerCount / 3600;
                    int minute = TimerCount % 3600 / 60;
                    int second = TimerCount % 3600 % 60;
                    sb.append(hour >= 10 ? hour + "" : "0" + hour);
                    sb.append(":");
                    sb.append(minute >= 10 ? minute + "" : "0" + minute);
                    sb.append(":");
                    sb.append(second >= 10 ? second + "" : "0" + second);
                    ((AudioInputActivity) mContext).setTimerCount(sb.toString());
                    break;
                case 4:
                    ((AudioInputActivity) mContext).playIsOver();
            }
        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_input);
        if(ContextCompat.checkSelfPermission(AudioInputActivity.this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AudioInputActivity.this,new String[]{Manifest.permission.RECORD_AUDIO},1);
        }
        mStartRecordButton = (ImageButton)findViewById(R.id.startRecordButton);
        mTimeTextView = (TextView)findViewById(R.id.timeTextView);
        mStartPlayButton = (ImageButton)findViewById(R.id.startPlayButton);
        mNextButton = (Button)findViewById(R.id.nextButton);
        mTimeTextView.setVisibility(View.INVISIBLE);

        mContext = AudioInputActivity.this;
        mStartRecordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable.ConstantState  constantState = mStartRecordButton.getDrawable().getCurrent().getConstantState();
                Drawable.ConstantState constState2 = getDrawable(R.drawable.record).getConstantState();
                if(constantState == constState2){
                    mStartRecordButton.setImageResource(R.drawable.stop2);
                    if(mRecorder==null) {
                        mRecorder = new SpeexRecorder();
                        mThread = new Thread(mRecorder);
                        mTimeTextView.setVisibility(View.VISIBLE);
                        mTimeTextView.setText("00:00:00");
                        TimerCount = 0;
                        mThread.start();
                        timer = new Timer(true);
                        task = new MyTask();
                        timer.schedule(task, 1000, 1000);
                    }
                    mRecorder.setRecording(true);
                }else{
                    mStartRecordButton.setImageResource(R.drawable.record);
                    mRecorder.setRecording(false);
                    timer.cancel();
                    mTimeTextView.setVisibility(View.INVISIBLE);
                    mRecorder = null;
                }
            }
        });
        mStartPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable.ConstantState  constantState = mStartPlayButton.getDrawable().getCurrent().getConstantState();
                Drawable.ConstantState constState2 = getDrawable(R.drawable.playblue).getConstantState();
                if(constantState == constState2){
                    if(splayer!=null) {
                        if (splayer.isPause()) {
                            splayer.startStopedPlay();
                            mStartPlayButton.setImageResource(R.drawable.pause2);
                        }
                    }else {
                        if (mPlayData != null) {
                            list0 = C000.ToL(mPlayData, mPlaySize);
                            SpeexPlayer.list0 = list0;
                            SpeexPlayer.startActivtiy="AudioInputActivity";
                            splayer = new SpeexPlayer();
                            splayer.startPlay();//开始播放
                            mStartPlayButton.setImageResource(R.drawable.pause2);
                        }
                    }

                }
                else{
                    mStartPlayButton.setImageResource(R.drawable.playblue);
                    if(splayer!=null){
                        splayer.stopPlay();
                    }
                }
            }
        });
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mPlayData != null) {
                    Intent intent = new Intent(AudioInputActivity.this,CoverSelectActivity.class);
                    intent.putExtra("data",mPlayData);
                    intent.putExtra("flag", flag);
                    startActivity(intent);
                    mPlayData = null;
                    finish();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "请录入秘密语音!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 1:
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_DENIED){
                    Toast.makeText(AudioInputActivity.this,"请允许应用访问麦克风权限，否则应用将无法正常使用",Toast.LENGTH_SHORT).show();
                }
        }
    }

    private class MyTask extends TimerTask {

        @Override
        public void run() {
            // TODO Auto-generated method stub
            Message message = new Message();
            message.what = 3;
            handler.sendMessage(message);
        }
    }
    public void setTimerCount(String time) {

        mTimeTextView.setText(time);

    }
    public void playIsOver() {
        if(splayer!=null){
            splayer.stopPlay();
            splayer = null;
        }
        mStartPlayButton.setImageResource(R.drawable.playblue);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mPlayData = null;
    }
}
