package com.example.guan.stegwechat;
import java.util.List;
public class SpeexPlayer{
    // private String fileName = null;
    private J001 speexdec = null;
    public static List<D000> list0 = null;
    Thread th;

    public String getStartActivtiy() {
        return startActivtiy;
    }

    public void setStartActivtiy(String startActivtiy) {
        this.startActivtiy = startActivtiy;
    }

    public static  String startActivtiy;
    public SpeexPlayer() {
        try {
            speexdec = new J001();
            speexdec.setList0(list0);//zjm 在初始化播放器对象前，需要对list0先进行赋值
            speexdec.setStartPlayActivity(this.startActivtiy);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startPlay() {
        RecordPlayThread rpt = new RecordPlayThread();
        th = new Thread(rpt);
        th.start();
    }

    public void stopPlay() {
        if (speexdec != null)
            speexdec.setPaused(true);
    }
    public void startStopedPlay() {
        if (speexdec != null)
            speexdec.setPaused(false);
    }
    public boolean isPause() {
        if(speexdec!=null){
            return speexdec.isPaused();
        }
        return true;
    }

    boolean isPlay = true;

    class RecordPlayThread extends Thread {

        public void run() {
            try {
                if (speexdec != null)
                    speexdec.decode();

            } catch (Exception t) {
                t.printStackTrace();
            }
        }
    }
}
