package com.example.guan.stegwechat;

import java.util.ArrayList;
import java.util.List;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Message;
import android.os.RecoverySystem.ProgressListener;


public class J001 {

	protected S000 speexDecoder;
	private List<D000> list0 = null;
	protected boolean enhanced = false;
	private boolean paused = false;
	private List<ProgressListener> listenerList = new ArrayList<ProgressListener>();
	// ������
	private AudioTrack track;

	public String getStartPlayActivity() {
		return startPlayActivity;
	}

	public void setStartPlayActivity(String startPlayActivity) {
		this.startPlayActivity = startPlayActivity;
	}

	private String startPlayActivity;
	/**
	 * 
	 * @param sampleRate
	 * @throws Exception
	 */
	private void initializeAndroidAudio(int sampleRate) throws Exception {
		int minBufferSize = AudioTrack.getMinBufferSize(sampleRate,
				AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);

		if (minBufferSize < 0) {
			throw new Exception("Failed to get minimum buffer size: "
					+ Integer.toString(minBufferSize));
		}

		track = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
				AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
				minBufferSize, AudioTrack.MODE_STREAM);

	}

	public void addOnMetadataListener(ProgressListener l) {
		listenerList.add(l);
	}

	public synchronized void setPaused(boolean paused) {
		this.paused = paused;
	}

	public synchronized boolean isPaused() {
		return paused;
	}


	public void decode() throws Exception {
		// �����µĽ�����
		speexDecoder = new S000();
		// ��ʼ��
		int decsize = 0;
		speexDecoder.init();
		initializeAndroidAudio(8000);
		
		while (list0.size() > 0) {
			if (Thread.interrupted()) {
				track.stop();// ֹͣ����
				return;
			}
			while (this.isPaused()) {// ֹͣ��
				track.stop();
				Thread.sleep(100);
			}
			D000 c = list0.remove(0);
			short[] decoded = new short[160];// ����������
			if ((decsize = speexDecoder.decode(c.getData(), decoded, 160)) > 0) {

				track.write(decoded, 0, decsize);

				track.setStereoVolume(0.7f, 0.7f);// ���õ�ǰ������С

				track.play();

			}

		}
		Message msg = new Message();
		msg.what = 4;
		if(this.startPlayActivity=="AudioInputActivity") {
			AudioInputActivity.handler.sendMessage(msg);
		}else {
			AudioOutputActivity.handler.sendMessage(msg);
		}
	}

	public List<D000> getList0() {
		return list0;
	}

	public void setList0(List<D000> list0) {
		this.list0 = list0;
	}


	protected static int readInt(final byte[] data, final int offset) {
		/*
		 * no 0xff on the last one to keep the sign
		 */
		/*
		 * int��4���ֽ�
		 */
		return (data[offset] & 0xff) | ((data[offset + 1] & 0xff) << 8)
				| ((data[offset + 2] & 0xff) << 16) | (data[offset + 3] << 24);
	}


	protected static long readLong(final byte[] data, final int offset) {
		/*
		 * no 0xff on the last one to keep the sign
		 */
		/*
		 * long��8���ֽ�
		 */
		return (data[offset] & 0xff) | ((data[offset + 1] & 0xff) << 8)
				| ((data[offset + 2] & 0xff) << 16)
				| ((data[offset + 3] & 0xff) << 24)
				| ((data[offset + 4] & 0xff) << 32)
				| ((data[offset + 5] & 0xff) << 40)
				| ((data[offset + 6] & 0xff) << 48) | (data[offset + 7] << 56);
	}


	protected static int readShort(final byte[] data, final int offset) {

		return (data[offset] & 0xff) | (data[offset + 1] << 8);
	}

}
