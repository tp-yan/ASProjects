package com.example.guan.stegwechat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.widget.Toast;

import com.example.guan.stegwechat.adapter.SectionsPagerAdapter;
import com.example.guan.stegwechat.service.VideoIntentService;

import static com.example.guan.stegwechat.service.VideoIntentService.BROADCAST_ACTION_VIDEO_RESULT;
import static com.example.guan.stegwechat.service.VideoIntentService.EXTRA_VIDEO_RESULT;

public class MainInterface extends AppCompatActivity {
    private static final String TAG = "MainInterface";
    private ViewPager viewPager;
    SectionsPagerAdapter pagerAdapter;

    private static boolean succeeded = false;
    public static byte[] randomVideoKeys;
    public static int randSeed;
    private LocalBroadcastManager localBroadcastManager;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (BROADCAST_ACTION_VIDEO_RESULT.equals(intent.getAction())) {
                int[] data = intent.getIntArrayExtra(EXTRA_VIDEO_RESULT);
                randomVideoKeys = new byte[40]; // 密钥
                for (int i = 0; i < 40; i++) {
                    randomVideoKeys[i] = (byte) data[i];
                    Log.d(TAG, "byte: " + randomVideoKeys[i]);
                }
                randSeed = data[data.length - 1]; // 随机数
                Log.d(TAG, "randSeed: " + randSeed);

                succeeded = true;
            }
        }
    };

    // 从外部获取密钥是否成功提取的状态信息
    public static boolean getFlag() {
        return succeeded;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTabLayout();

        localBroadcastManager = LocalBroadcastManager.getInstance(this);
        registerReceiver();

        while (ContextCompat.checkSelfPermission(MainInterface.this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainInterface.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }

        // 启动后台服务提取密钥
        Intent videoIntent = new Intent(this, VideoIntentService.class);
        startService(videoIntent);
    }

    private void registerReceiver() {
        IntentFilter intentFilter = new IntentFilter(BROADCAST_ACTION_VIDEO_RESULT);
        localBroadcastManager.registerReceiver(receiver, intentFilter);
    }

    // 采用 Tab标签 + ViewPager 布局
    private void setTabLayout() {
        setContentView(R.layout.activity_main_tabbed);
        viewPager = findViewById(R.id.viewPager);
        pagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter); // 给 viewPager 绑定 Adapter，喂数据

        // 将TabLayout与viewPager建立关联，即可实现相互监听滑动事件
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_exit) {
            System.exit(0);
        } else if (id == R.id.action_help) {
            Intent intent = new Intent(MainInterface.this, HelpActivity.class);
            startActivity(intent);
        } else if (id == R.id.action_config) {
            Intent intent = new Intent(MainInterface.this, Config_Setting.class);
            startActivity(intent);
        } else if (id == R.id.action_extract) {
            Intent intent = new Intent(MainInterface.this, ImgExtractActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        localBroadcastManager.unregisterReceiver(receiver);
    }
}
