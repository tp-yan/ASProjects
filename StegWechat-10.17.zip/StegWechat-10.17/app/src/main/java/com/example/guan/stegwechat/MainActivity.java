package com.example.guan.stegwechat;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    Button login;
    EditText et_password;
    ImageView iv_see_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (Button) findViewById(R.id.btn_login);
        et_password = (EditText) findViewById(R.id.et_password);
        iv_see_password = (ImageView) findViewById(R.id.iv_see_password);
        PrivateHash privateHash = (PrivateHash) getApplication();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = et_password.getText().toString();
                if (password.isEmpty()){
                    showToast("登录口令为空！");
                    return;
                }
                File sys_file_path = getExternalFilesDir(null);
                String read_path = sys_file_path.getPath();
                String file_path_md5 = read_path + "/md5.txt";
                String file_path_embedkey = read_path + "/embed_key.txt";
                File md5_file = new File(file_path_md5);
                if (!md5_file.exists()){
                    showToast("口令校验文件不存在！");
                    return;
                }
                String user_MD5 = privateHash.getMD5(password);
                String read_md5 = privateHash.key_file(file_path_md5);

                if (!(user_MD5.equals(read_md5))){
                    showToast("口令错误，请重新输入！");
                    return;
                }
                privateHash.put_password(password);
                privateHash.file_embedkey(file_path_embedkey);
                Intent intent = new Intent(MainActivity.this, MainInterface.class);
                startActivity(intent);
                finish();
            }
        });
        iv_see_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (iv_see_password.isSelected()) {
                    iv_see_password.setSelected(false);
                    //密码不可见
                    et_password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

                } else {
                    iv_see_password.setSelected(true);
                    //密码可见
                    et_password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                }
            }
        });
    }
    public void showToast(String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });

    }

}
