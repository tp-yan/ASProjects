package com.example.guan.stegwechat;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import android.content.SharedPreferences;
import java.io.File;
import java.lang.reflect.Array;
import java.util.Arrays;

public class extract extends AppCompatActivity {

    SharedPreferences sharedpreferences;
    public static final String mypreference = "configure";
    public static final String embedkey = "embedKey";
    public static final String stc_h = "stc_hKey";
    public static final String payload = "payloadKey";
    int symbol =1;
    protected void onCreate(Bundle savedInstanceState) {
        sharedpreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        String seed = sharedpreferences.getString(embedkey, "");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.extract);
        long begintime = System.currentTimeMillis();
        String stegopath="/storage/emulated/0/DCIM/Camera/IMG_20190703_091608_rc_STC.jpg";

        new ExtractThreadTask().execute(stegopath,seed,Double.toString(begintime) );
    }

    @Override
    public void onBackPressed() {
        if(symbol == 1){
            Toast.makeText(getApplicationContext(), "当前提取过程未完成，请稍等！",
                    Toast.LENGTH_SHORT).show();
        }
        else{
            super.onBackPressed();
        }
    }

    private class ExtractThreadTask extends AsyncTask<String, Integer, byte[]> {
        protected byte[] doInBackground(String... params) {    //byte
            int count = params.length;
            String AllPathh = params[0];
            int seedh = Integer.parseInt(params[1]);
            double begintimeh = Double.parseDouble(params[2]);
            PrivateHash privateHash = (PrivateHash) getApplication();
            String password = privateHash.get_password();
            byte[] flag = StegoAlgorithm.algorithmtype(AllPathh, password, seedh); //byte
//            String process_time = Double.toString((System.currentTimeMillis() - begintimeh)/1000);
//            flag = flag +"||"+process_time;

            return flag;
        }

//        protected void onProgressUpdate(Integer... progress) {
//            setProgressPercent(progress[0]);
//        }

        protected void onPostExecute(final byte[] result) {
//            String[] each_file_path = result.split("\\|\\|");
//            showresult.setText("提取完成，共耗时"+each_file_path[1]+"s");
            AlertDialog.Builder builder = new AlertDialog.Builder(extract.this);
            //设置对话框标题
            builder.setTitle("系统提示");
            builder.setCancelable(false);
            byte errflag=0;
            //设置对话框内的文本
            if(errflag==result[0])
            {
                builder.setMessage("该图没有嵌入消息！");
                //设置确定按钮
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        skip();
                    }
                });
            }
            else
            {
                builder.setMessage("提取完成！");
                //设置确定按钮
                builder.setNegativeButton("展示秘密信息", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        byte msg_type=result[0];
                        int datalength = result.length-2;
                        byte []data = new byte[datalength];
                        System.arraycopy(result, 1, data, 0, datalength);
                        if (msg_type==1) {
                            Intent intent = new Intent(extract.this, ShowText.class);
                            String text = new String(data);
                            intent.putExtra("data", text);
                            startActivity(intent);
                        }
                        else if(msg_type==2)
                        {
                            Intent intent = new Intent(extract.this, AudioOutputActivity.class);
                            intent.putExtra("data", data);
                            startActivity(intent);
                        }
                    }
                });
            }

            //使用builder创建出对话框对象
            AlertDialog dialog = builder.create();
            //显示对话框
            dialog.show();
        }
        private void skip() {
            Intent intent2 = new Intent();
            intent2.setClass(extract.this, MainActivity.class);
            startActivity(intent2);
        }
    }
}
