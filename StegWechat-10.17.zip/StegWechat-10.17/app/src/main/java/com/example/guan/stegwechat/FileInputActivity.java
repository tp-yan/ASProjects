package com.example.guan.stegwechat;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import ru.bartwell.exfilepicker.ExFilePicker;
import ru.bartwell.exfilepicker.data.ExFilePickerResult;

public class FileInputActivity extends AppCompatActivity {
    ListView pickFileListView = null;
    Button pickFileButton = null;
    Button pickFileNextButton = null;
    Button selectAllButton = null;
    Button deleteButton  = null;
    ArrayAdapter<String> adapter1;
    private ArrayList<String> arr1 = new ArrayList<String>();
    private ArrayList<String> fileArr = new ArrayList<String>();
    private String startDirectory = null;
    private static final int EX_FILE_PICKER_RESULT = 1;
    private Uri contentUri;
    byte[] zipByteArr;
    Boolean selectAllFile = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_input);
        pickFileListView = (ListView)findViewById(R.id.fileList);
        pickFileButton = (Button)findViewById(R.id.pickFileButton);
        pickFileNextButton = (Button)findViewById(R.id.pickFileNextButton);
        selectAllButton = (Button)findViewById(R.id.file_select_all);
        deleteButton = (Button)findViewById(R.id.file_delete);
        adapter1 = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_multiple_choice, arr1);
        pickFileListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        pickFileListView.setAdapter(adapter1);
        pickFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExFilePicker exFilePicker = new ExFilePicker();
                //exFilePicker.setCanChooseOnlyOneItem(true);// 单选
                exFilePicker.setQuitButtonEnabled(true);
                if (TextUtils.isEmpty(startDirectory)) {
                    exFilePicker.setStartDirectory(Environment.getExternalStorageDirectory().getPath());
                } else {
                    exFilePicker.setStartDirectory(startDirectory);
                }
                exFilePicker.setChoiceType(ExFilePicker.ChoiceType.FILES);
                exFilePicker.start(FileInputActivity.this, EX_FILE_PICKER_RESULT);
            }
        });
        pickFileNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (arr1.isEmpty())
                {
                    Toast.makeText(getApplicationContext(), "请添加嵌入文件!",
                            Toast.LENGTH_SHORT).show();
                }
                else
                {
                    SparseBooleanArray checkedItems1 = pickFileListView.getCheckedItemPositions();
                    String zip_path = "";
                    int i = 0;
                    String s = fileArr.get(i).toString();//以第一个文件名的文件路径作为压缩文件的文件名
                    for (int j = 0; j < s.length(); j ++)
                    {
                        if (s.charAt(j) == '.')
                            break;
                        else
                            zip_path += s.charAt(j);
                    }
                    zip_path += "_atall.zip";
                    try {
                        ZipFile zipFile = new ZipFile(zip_path);
                        ArrayList filesToAdd = new ArrayList();
                        for(int j = 0;j < checkedItems1.size();j ++)
                        {
                            if (checkedItems1.valueAt(j) == true)
                            {
                                String each_file_path = fileArr.get(j).toString();
                                filesToAdd.add(new File(each_file_path));
                            }
                        }
                        ZipParameters parameters = new ZipParameters();
                        parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
                        parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
                        zipFile.addFiles(filesToAdd, parameters);
                        zipByteArr = fileConvertToByteArray(new File(zip_path));
                        sendByIntent(zipByteArr,CoverSelectActivity.class);
                    }
                    catch (ZipException e) {
                        e.printStackTrace();
                    }
                }
            }});
        selectAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean value;

                if(selectAllFile){// 若原本是全选，点击后，则全不选
                    selectAllFile =  value = false;
                }else{
                    selectAllFile =  value = true;
                }
                SparseBooleanArray checkedItems = pickFileListView.getCheckedItemPositions();
                for (int i = 0; i < arr1.size(); i++) {
                    checkedItems.put(i, value);  // map类型的结构，key：int,value:bool。覆盖之前的值
                }
                adapter1.notifyDataSetChanged();
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SparseBooleanArray checkedItems = pickFileListView.getCheckedItemPositions();
                //逆序删除 避免索引越界
                for (int i = checkedItems.size() - 1; i >= 0; i--) {
                    if (checkedItems.valueAt(i)) {
                        // 文件名数组与文件路径数组必须同步
                        arr1.remove(i);
                        fileArr.remove(i);
                        checkedItems.delete(i);
                    }
                }

                selectAllFile = false;
                adapter1.notifyDataSetChanged();
            }
        });
    }
    private void sendByIntent(byte[] byteArr,Class<?> activity){
        Intent intent = new Intent(FileInputActivity.this,activity);
        intent.putExtra("flag",4);
        intent.putExtra("data",byteArr);
        startActivity(intent);
    }
    private byte[] fileConvertToByteArray(File file) {
        byte[] data = null;

        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            int len;
            byte[] buffer = new byte[1024];
            while ((len = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }

            data = baos.toByteArray();

            fis.close();
            baos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case 1:
                ExFilePickerResult result = ExFilePickerResult.getFromIntent(data);
                if (result != null && result.getCount() > 0) {
                    String filedirh;
                    List<String> filename = result.getNames();
                    filedirh = result.getPath();
                    startDirectory = filedirh;
                    String sp = filedirh+filename.get(0);
                    if(fileArr.contains(sp)){
                        return;
                    }
                    if (Build.VERSION.SDK_INT < 24) {
                        fileArr.add(sp);//filedirh+filename.get(0)
                    }else
                    {
                        File hnewFile = new File(filedirh,filename.get(0));
                        contentUri = FileProvider.getUriForFile(this,"com.example.guan.stegwechat", hnewFile);
                        fileArr.add(sp);//contentUri.toString()
                    }
                    arr1.add(filename.get(0));
                    SparseBooleanArray checkedItems2 = pickFileListView.getCheckedItemPositions();
                    int k = arr1.size()- 1;
                    checkedItems2.put(k, true);
                    adapter1.notifyDataSetChanged();
                }
                break;
            default:
                break;
        }

    }
}
