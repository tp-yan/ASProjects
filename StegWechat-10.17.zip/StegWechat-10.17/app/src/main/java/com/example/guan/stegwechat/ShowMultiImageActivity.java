package com.example.guan.stegwechat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowMultiImageActivity extends Activity {
    private static final String TAG = "ShowMultiImageActivity";

    RecyclerView recyclerView;
    ArrayList<byte[]> byteList;
    RecycleScaleAdapter adapter;

    private Button takeAgain,finish;
    private LinearLayout linearLayout;  // takeAgain,finish的父控件

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_multi_image);

        takeAgain = (Button) findViewById(R.id.take_photo_again);
        finish = (Button) findViewById(R.id.finish);
        linearLayout = (LinearLayout) findViewById(R.id.linear_layout);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(manager);

        initByteList();
        adapter = new RecycleScaleAdapter(this, byteList);
        recyclerView.setAdapter(adapter);
    }

    // 获取传过来的图像数据，对byteList初始化
    private void initByteList() {
        Intent intent = getIntent();
        int flag = intent.getIntExtra("flag", -1);
        if (flag == -1) {
            Toast.makeText(this, "获取数据失败！", Toast.LENGTH_SHORT).show();
            finish();
        } else if (flag == 0) { // 图像路径：展示一张
            String imgPath = intent.getStringExtra("imgPath");
            Log.d(TAG, "initByteList--imgPath: "+imgPath);
            byteList = new ArrayList<>();
            byte[] bytes = Utils.File2Byte(imgPath);
            byteList.add(bytes);
            Log.d(TAG, "flag == 0: "+ bytes.length/(1024*1024.0) + "M");
        } else if (flag == 1) {// 提取图像bytes：展示多张
            byte[] imgBytes = intent.getByteArrayExtra("data");
            byteList = Utils.byte2ArrayList(imgBytes);
        } else if (flag == 2) {// 拍照图片bytes：展示一张
            byteList = new ArrayList<>();
            byte[] data = intent.getByteArrayExtra("data");
            byteList.add(data);
            Log.d(TAG, "flag == 2: " + byteList);
        }else if (flag == 3) {// 预览照片
            byteList = new ArrayList<>();
            byte[] data = intent.getByteArrayExtra("data");
            byteList.add(data);
            doExtraThing();
        }
    }

    private void doExtraThing(){
        linearLayout.setVisibility(View.VISIBLE);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("flag",2);
                setResult(RESULT_OK,intent);
                finish();
            }
        });
        takeAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePictureAgain();
            }
        });
    }

    private void takePictureAgain(){
        Intent intent = new Intent();
        intent.putExtra("flag",1);
        setResult(RESULT_OK,intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (linearLayout != null){
            if(linearLayout.getVisibility() == View.VISIBLE){
                takePictureAgain();
            }else{
                finish();
            }
        }else{
            finish();
        }
    }
}
