package com.example.guan.stegwechat;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.bumptech.glide.util.Util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;

import me.nereo.multi_image_selector.MultiImageSelectorActivity;
import me.nereo.multi_image_selector.utils.FileUtils;
import me.shaohui.advancedluban.OnCompressListener;

public class CoverSelectActivity extends PickImageActivity {
    private static final String TAG = "CoverSelectActivity";
    private ProgressDialog progressDialog;

    protected String hint_1 = "请添加载体图片！";
    protected String hint_2 = "请选中载体图片！";

    // 图像压缩尺寸为原来尺寸的宽高比
    private float scaleW = 0.7f;
    private float scaleH = 0.7f;
    // 压缩质量因子
    private int IMG_QUALITY = 50;

    ArrayList<String> imgPath;
    Bundle bundle;
    ArrayList<byte[]> imgData;

    // 从Intent接收的数据
    private byte[] data;
    private int flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FileUtils.JPEG_FILE_PREFIX = "IMG_COVER_";
        showCamera = true;
        setContentView(R.layout.activity_cover_select);
        parseIntent();
        getWidgets();
    }

    private void parseIntent() {
        Intent intent = getIntent();

        flag = intent.getIntExtra("flag", 0);
        switch (flag) {
            case 1: // 文字
                data = intent.getByteArrayExtra("data");
                break;
            case 2: // 音频
                data = intent.getByteArrayExtra("data");
                break;
            case ImgPickActivity.INTENT_IMAGE_FLAG: // 图像
                bundle = intent.getBundleExtra("imgData");
                imgPath = intent.getStringArrayListExtra("imgPath");
                if (imgPath != null || bundle != null) {
                    getImageData();
//                    ArrayList<byte[]> tmp = Utils.byte2ArrayList(data);
//                    showCameraImg(tmp.get(1));
//                    Log.d(TAG, "ArrayList<byte[]> tmp--size: "+tmp.size());
                }
                break;
            case 4: // 文件
                data = intent.getByteArrayExtra("data");
                break;
        }
    }

    private void getImageData() {
        imgData = new ArrayList<>();
        if (bundle != null) {
            for (String key : bundle.keySet()) {
                byte[] tmp = bundle.getByteArray(key);
                imgData.add(tmp);
                Log.d(TAG, "bundle: " + key + "-->" + tmp.length / 1024 + "K");
            }
        }
        if (imgPath != null && imgPath.size() > 0) {
            for (String path : imgPath) {
                // 压缩图像并添加到imgData
                byte[] tmp = Utils.File2Byte(path);
                Log.d(TAG, "imgPath: 压缩前大小" + path + "-->" + tmp.length / 1024 + "K");
                compressImage(path);
            }
        }
    }

    // 压缩本地选择的图片
    private void compressImage(String imgPath) {
        File file = new File(imgPath);
        Utils.compressImg(this, file, new OnCompressListener() {
            @Override
            public void onStart() {

            }

            @Override
            public void onSuccess(File file) {
                Bitmap bitmap = Utils.getLocalBitmap(file.getAbsolutePath());
                // 压缩图像尺寸
                Log.d(TAG, "压缩前尺寸: " + bitmap.getWidth() + "*" + bitmap.getHeight());
                bitmap = Utils.downSample(bitmap, scaleW, scaleH);
                Log.d(TAG, "压缩后尺寸: " + bitmap.getWidth() + "*" + bitmap.getHeight());
                // 对图像按质量因子压缩不改变尺寸
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, IMG_QUALITY, baos);
                byte[] data = baos.toByteArray();
                imgData.add(data);
                Log.d(TAG, "imgPath: 压缩后图像大小：" + data.length / 1024 + "K");

                if (file.exists()) {
                    Log.d(TAG, "delete compressed file");   // 删除压缩时的临时文件
                    file.delete();
                }
            }

            @Override
            public void onError(Throwable e) {

            }
        }, COMPRESS_WECHAT);
    }

    private void getWidgets() {
        addImg = (Button) findViewById(R.id.add_file);
        selectAll = (Button) findViewById(R.id.select_all);
        delete = (Button) findViewById(R.id.delete);
        nextStep = (Button) findViewById(R.id.next_btn);
        imgListView = (ListView) findViewById(R.id.file_list);

        addImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImg();
            }
        });

        selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAllFile();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFileFromList();
            }
        });
        // 嵌入按钮
        nextStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imgListData.isEmpty()) {
                    Toast.makeText(getApplicationContext(), hint_1,
                            Toast.LENGTH_SHORT).show();
                } else {
                    if (flag == 3) {
                        data = Utils.arrayList2Byte(imgData);
                        Log.d(TAG, "最后的data大小：: " + data.length / 1024 + "K");
                    }
                    if (MainInterface.getFlag()) {
                        callEmbedFunction(MainInterface.randSeed, MainInterface.randomVideoKeys);
                    } else {
                        Toast.makeText(CoverSelectActivity.this, "视频密钥提取中，无法嵌入！", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

        imgListAdapter = new ArrayAdapter<>(CoverSelectActivity.this, android.R.layout.simple_list_item_multiple_choice, imgListData);
        imgListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        imgListView.setAdapter(imgListAdapter);
        imgListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showImgDialog(imgPaths.get(position), imgListData.get(position));
                return true; // 返回true不会触发点击事件
            }
        });
    }

    // 调用嵌入算法进行嵌入
    private void callEmbedFunction(int randSeed, byte[] randomVideoKeys) {
        SparseBooleanArray checkedItems = imgListView.getCheckedItemPositions();
        ArrayList<String> selectPics = new ArrayList<>();
        for (int i = 0; i < checkedItems.size(); i++) {
            if (checkedItems.valueAt(i)) {
                selectPics.add(imgPaths.get(i));
            }
        }
        if (selectPics.isEmpty()) {
            Toast.makeText(CoverSelectActivity.this, hint_2, Toast.LENGTH_SHORT).show();
            return;
        }
        // finalPicPath：包含多个载体路径
        StringBuilder finalPicPath = new StringBuilder();
        for (int i = 0; i < selectPics.size() - 1; i++) {
            finalPicPath.append(selectPics.get(i));
            finalPicPath.append("||");
        }
        finalPicPath.append(selectPics.get(selectPics.size() - 1));

        Log.d(TAG, "finalPicPath: " + finalPicPath.toString());

        ArrayList<String> configs = getConfig(CoverSelectActivity.this);
        for (String config : configs)
            if (config.equals("")) {
                Toast.makeText(this, "嵌入参数不完整，请填写！", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(CoverSelectActivity.this, Config_Setting.class);
                startActivity(intent);
                return;
            }

        new EmbedThreadTask().execute(finalPicPath.toString(), configs.get(0), configs.get(1),
                configs.get(2), configs.get(3), randSeed, randomVideoKeys);
    }

    // 获取STC配置参数 embedKey stc_h payload
    protected ArrayList<String> getConfig(Context context) {
        ArrayList<String> params = new ArrayList<>();
        SharedPreferences sharedpreferences = context.getSharedPreferences(Config_Setting.mypreference,
                Context.MODE_PRIVATE);
        PrivateHash privateHash = (PrivateHash) getApplication();
        params.add(privateHash.get_embed_key());
        params.add(privateHash.get_password());
        params.add(sharedpreferences.getString(Config_Setting.stc_h, ""));
        params.add(sharedpreferences.getString(Config_Setting.payload, ""));

        return params;
    }

    // 开启子线程来完成嵌入
    private class EmbedThreadTask extends AsyncTask<Object, Integer, String> {

        @Override
        protected void onPreExecute() {
            // 调用子线程前，在这里完成界面的初始化工作
            super.onPreExecute();
            progressDialog = new ProgressDialog(CoverSelectActivity.this);
            progressDialog.setTitle("系统提示");
            progressDialog.setMessage("正在嵌入，请等待...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            // 参数s：doInBackground的返回结果
            super.onPostExecute(s);
            Log.d(TAG, "onPostExecute: 嵌入返回result:\n" + s);
            if (progressDialog != null && progressDialog.isShowing())
                progressDialog.dismiss();

            //  /storage/emulated/0/DCIM/IMG_8620877494473722580_STC.jpg||success||14.42
            //分离图片的输出路径
            final String[] each_file_path = s.split("\\|\\|"); //  分隔符：||

            final ArrayList<String> paths = new ArrayList<>();
            for (int i = 0; i < each_file_path.length - 2; i++) {
                paths.add(each_file_path[i]);
                String out = each_file_path[i];
                File file = new File(out);
                Uri uri = Uri.fromFile(file);
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
            }

            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CoverSelectActivity.this);
            dialogBuilder.setTitle("系统提示");
            dialogBuilder.setCancelable(false);
            if ("error".equals(each_file_path[each_file_path.length - 2])) {
                dialogBuilder.setMessage("消息过长，嵌入失败！");
                dialogBuilder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 先删除已嵌入的图像
                        for (String p : paths) {
                            File file = new File(p);
                            if (file.exists()) {
                                file.delete();
                            }
                        }
                    }
                });
            } else {
                dialogBuilder.setMessage("嵌入成功！" + "共耗时" + each_file_path[each_file_path.length - 1]
                        + "s.");
                dialogBuilder.setPositiveButton("完成", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(CoverSelectActivity.this, MainInterface.class);
                        startActivity(intent);
                        finish();
                    }
                });
            }
            dialogBuilder.create();
            dialogBuilder.show();
        }

        @Override
        protected String doInBackground(Object... objects) {
            String coverPath = (String) objects[0];
            String embedKey = (String) objects[1];
            String password = (String) objects[2];
            String stc_h = (String) objects[3];
            String payload = (String) objects[4];
            int randSeed = (int) objects[5];
            byte[] randomKeys = (byte[]) objects[6];

            File app_path = getExternalCacheDir();
            String Apppath = app_path.getPath();
            System.out.println(Apppath);
            long beginTime = System.currentTimeMillis();

            // 输入可能是多张图片，有可能只嵌入了一部分图片，这里返回的是实际嵌入的图片的绝对路径
            String embedResult = StegoAlgorithm.STCembed(coverPath, Apppath, data, password, flag,
                    Integer.parseInt(embedKey), Double.parseDouble(payload), Integer.parseInt(stc_h),
                    randSeed, randomKeys);
            String process_time = Double.toString((System.currentTimeMillis() - beginTime) / 1000.0);
            embedResult = embedResult + "||" + process_time;

            /* 模拟嵌入过程
            String embedResult = "/storage/emulated/0/DCIM/IMG_8620877494473722580_STC.jpg|| success || 12.24";
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            */

            return embedResult;     // 结果作为参数传入onPostExecute()
        }
    }

}
