package com.example.guan.stegwechat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;

import me.nereo.multi_image_selector.MultiImageSelectorActivity;
import me.nereo.multi_image_selector.utils.FileUtils;

public class ImgPickActivity extends PickImageActivity {
    private static final String TAG = "ImgPickActivity";

    protected String hint_1 = "请添加密文图片！";
    protected String hint_2 = "请选中密文图片！";
    public static final int INTENT_IMAGE_FLAG = 3;
    public static final int INTENT_MY_CAMERA = 209;

    private String[] mPermissions = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FileUtils.JPEG_FILE_PREFIX = "IMG_SKL_SGH_";
        setContentView(R.layout.activity_img_pick);

        questPermission();
        getWidgets();
    }

    private void questPermission() {
        RxPermissions rxPermissions = new RxPermissions(this);
        rxPermissions.request(Manifest.permission.CAMERA,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(granted -> {
                    if (granted) {
                    } else {
                        // At least one permission is denied
                        Toast.makeText(this, "需要拍照与读写权限！", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    /**
     * 判断是否缺少权限，缺少权限返回true
     */
    private static boolean lacksPermission(Context mContexts, String permission) {
        return ContextCompat.checkSelfPermission(mContexts, permission) ==
                PackageManager.PERMISSION_DENIED;
    }

    /**
     * 判断权限集合
     * permissions 权限数组
     * return true-表示没有改权限  false-表示权限已开启
     */
    public boolean lacksPermissions(Context mContexts, String[] mPermissions) {
        for (String permission : mPermissions) {
            if (lacksPermission(mContexts, permission)) {
                Log.e("TAG", "-------没有开启权限");
                return true;
            }
        }
        Log.e("TAG", "-------权限已开启");
        return false;
    }


    private void getWidgets() {
        addImg = (Button) findViewById(R.id.add_file);
        selectAll = (Button) findViewById(R.id.select_all);
        delete = (Button) findViewById(R.id.delete);
        nextStep = (Button) findViewById(R.id.next_btn);
        imgListView = (ListView) findViewById(R.id.img_list);

        imgListAdapter = new ArrayAdapter<>(ImgPickActivity.this, android.R.layout.simple_list_item_multiple_choice, imgListData);
        imgListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        imgListView.setAdapter(imgListAdapter);
        // 长按展示图片
        imgListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String item = imgListData.get(position);
                if (cameraImg.containsKey(item)) {
                    showCameraImg(cameraImg.get(item));
                } else
                    showImgDialog(imgPaths.get(position), imgListData.get(position));
                return true;    // 返回true不会触发点击事件
            }
        });

        addImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] items = {"拍照", "相册"};
                AlertDialog.Builder builder = new AlertDialog.Builder(ImgPickActivity.this);
                builder.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0: // 拍照
                                if (!lacksPermissions(ImgPickActivity.this, mPermissions)) {
                                    startCamera();
                                } else {
                                    Toast.makeText(ImgPickActivity.this, "未授权相机权限！", Toast.LENGTH_SHORT).show();
                                }
                                break;
                            case 1:
                                pickImg();
                                break;
                        }
                    }
                });
                builder.create().show();
            }
        });
        selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAllFile();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFileFromList();
            }
        });

        nextStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData2CoverSelect();
            }
        });
    }

    // 启动自定义相机
    private void startCamera() {
        startActivityForResult(new Intent(ImgPickActivity.this,
                MyCameraActivity.class), INTENT_MY_CAMERA);
    }

    // 将选择的密文图像发送到载体选择界面
    private void sendData2CoverSelect() {
        ArrayList<String> selectImgPath = checkImgList(hint_1, hint_2);
        if (selectImgPath != null && selectImgPath.size() > 0) {
            Intent intent = new Intent(ImgPickActivity.this, CoverSelectActivity.class);
            ArrayList<String> paths = new ArrayList<>();
            Bundle bundle = new Bundle();
            for (String item : selectImgPath) {
                if (cameraImg.containsKey(item)) {
                    bundle.putByteArray(item, cameraImg.get(item));
                } else {
                    paths.add(item);    // 图片路径
                }
            }
            if (paths.size() > 0)
                intent.putExtra("imgPath", paths);
            if (bundle.size() > 0)
                intent.putExtra("imgData", bundle);
            intent.putExtra("flag", INTENT_IMAGE_FLAG);

            startActivity(intent);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == INTENT_MY_CAMERA) {
            if (resultCode == RESULT_OK) {
                // 添加 相机返回的图片
                String name = FileUtils.JPEG_FILE_PREFIX + System.currentTimeMillis();
                byte[] jpegData = data.getByteArrayExtra("camera_data");
                Log.d(TAG, "onActivityResult: jpegData" + jpegData.length/1024 + 'K');
                cameraImg.put(name, jpegData);
                // 添加到imgListData的尾部
                addItem2ImgListData(name);
                imgListAdapter.notifyDataSetChanged();
            }
        }
    }
}
