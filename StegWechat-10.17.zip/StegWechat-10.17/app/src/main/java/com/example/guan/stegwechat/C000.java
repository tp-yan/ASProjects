package com.example.guan.stegwechat;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class C000 {
	public static byte[] ToA(List<D000> list,int len) {
		byte[] result = new byte[len+20];
		int rsize=0;
		while (list.size() > 0) {
			D000 d = list.remove(0);
			byte[] src=d.getData();
			int size=d.getSize();
			System.arraycopy(src, 0, result, rsize, size);
			rsize+=size;
		}
		return result;
	}
	public static List<D000> ToL(byte[] Arr,int Asize){
		List<D000> result= Collections.synchronizedList(new LinkedList<D000>());
		int size=20;
		int c=Asize/size+1;
		for(int i=0;i<c;i++){
			D000 d=new D000();
			byte[] b=new byte[1024];
			System.arraycopy(Arr, i*size, b, 0, size);
			d.setData(b);
			d.setSize(size);
			result.add(d);
			
		}
		return result;
	}
	
}
