package com.example.guan.stegwechat.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.guan.stegwechat.R;
import com.example.guan.stegwechat.ShowMultiImageActivity;
import com.example.guan.stegwechat.Utils;

import java.util.ArrayList;

public class ShowImageRecyclerAdapter extends RecyclerView.Adapter<ShowImageRecyclerAdapter.ViewHolder> {
    private ArrayList<String> imgPathList;
    private Context context;

    public ShowImageRecyclerAdapter(ArrayList<String> imgPathList, Context context) {
        this.imgPathList = imgPathList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyler_show_img_item,
                parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        // 展示缩放图
        viewHolder.imageView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int position = viewHolder.getAdapterPosition();
                Intent intent = new Intent(context, ShowMultiImageActivity.class);
                intent.putExtra("imgPath", imgPathList.get(position));
                intent.putExtra("flag", 0);
                context.startActivity(intent);
                return true;
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // 根据路径加载图片
        Glide.with(context).load(imgPathList.get(position)).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return imgPathList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.image_view);
        }
    }
}
