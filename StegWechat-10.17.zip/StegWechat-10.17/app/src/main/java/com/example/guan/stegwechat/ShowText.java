package com.example.guan.stegwechat;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ShowText extends AppCompatActivity {

    TextView text;
    Button finsh;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_text);
        text= (TextView)findViewById(R.id.show_text);
        finsh=(Button)findViewById(R.id.show_text_finsh);
        Intent intent=getIntent();
        String data = intent.getStringExtra("data");
        text.setText(data);
        finsh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowText.this, MainInterface.class);
                startActivity(intent);
                finish();
            }
        });
    }
}