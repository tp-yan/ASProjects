package com.example.guan.stegwechat;
import java.util.List;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Message;
/**
 * 录音类
 *
 * @author 双剑
 *
 */
public class SpeexRecorder implements Runnable {

    private double volume=0.0;
    private volatile boolean isRecording;
    private final Object mutex = new Object();// 信号量
    private static final int frequency = 8000;
    private static final int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    public static int packagesize = 160;
    //private String fileName = null;
    public static List<D000> datalist=null;

    public SpeexRecorder() {
        super();
    }

    /**
     * 启动编码线程
     */
    public void run() {
        // 启动编码线程
        // 编码类实例
        J000 encoder = new J000();
        // 创建编码线程
        Thread encodeThread = new Thread(encoder);
        // 将isRecording置为true
        encoder.setRecording(true);
        // 编码线程启动
        encodeThread.start();

        synchronized (mutex) {// 锁住资源
            while (!this.isRecording) {// 当isRecording为false时
                try {
                    mutex.wait();//等待isRecording的置位
                } catch (InterruptedException e) {
                    throw new IllegalStateException("Wait() interrupted!", e);
                }
            }
        }
        // 设置线程权限为紧急
        android.os.Process
                .setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);

        int bufferRead = 0;
        // 获取缓冲区大小
        int bufferSize = AudioRecord.getMinBufferSize(frequency,
                AudioFormat.CHANNEL_IN_MONO, audioEncoding);

        short[] tempBuffer = new short[packagesize];
        // 创建录音机实例
        AudioRecord recordInstance = new AudioRecord(
                MediaRecorder.AudioSource.MIC, frequency,
                AudioFormat.CHANNEL_IN_MONO, audioEncoding, bufferSize);

        recordInstance.startRecording();

        //当处于录音过程中
        while (this.isRecording) {
            // 读取录音数据到tempBuffer 从0开始，读packagesize位
            bufferRead = recordInstance.read(tempBuffer, 0, packagesize);
            //错误处理
            if (bufferRead == AudioRecord.ERROR_INVALID_OPERATION) {
                throw new IllegalStateException(
                        "read() returned AudioRecord.ERROR_INVALID_OPERATION");
            } else if (bufferRead == AudioRecord.ERROR_BAD_VALUE) {
                throw new IllegalStateException(
                        "read() returned AudioRecord.ERROR_BAD_VALUE");
            } else if (bufferRead == AudioRecord.ERROR_INVALID_OPERATION) {
                throw new IllegalStateException(
                        "read() returned AudioRecord.ERROR_INVALID_OPERATION");
            }
            long v=0;
            for(int i=0;i<tempBuffer.length;i++){
                v+=tempBuffer[i]*tempBuffer[i];
            }
            double mean=v/(double)bufferRead;
            volume=10*Math.log10(mean);
            Message mes = new Message();
            mes.obj = volume;
            mes.what = 2;
            //AudioInputActivity.handler.sendMessage(mes);

            // 将数据送至编码器
            encoder.putData(tempBuffer, bufferRead);
        }

        //停止录音
        recordInstance.stop();

        // tell encoder to stop.这一句在另外一个线程里，会告诉当前线程，该停止了
        encoder.setRecording(false);
    }

    public void setRecording(boolean isRecording) {
        synchronized (mutex) {
            this.isRecording = isRecording;
            if (this.isRecording) {
                mutex.notify();
            }
        }
    }

    public double getVolume() {
        return volume;
    }

    public boolean isRecording() {
        synchronized (mutex) {
            return isRecording;
        }
    }
}
