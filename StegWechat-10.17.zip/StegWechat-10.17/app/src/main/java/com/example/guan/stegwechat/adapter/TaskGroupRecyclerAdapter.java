package com.example.guan.stegwechat.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.guan.stegwechat.R;
import com.example.guan.stegwechat.bean.SingleTask;

import java.util.ArrayList;

// 填充提取分组最外层 RecyclerView
public class TaskGroupRecyclerAdapter extends RecyclerView.Adapter<TaskGroupRecyclerAdapter.ViewHolder> {
    private ArrayList<SingleTask> taskList;
    private Context context;
    private SparseBooleanArray sparseBooleanArray;
    public int lastPosition = -1;

    public TaskGroupRecyclerAdapter(ArrayList<SingleTask> taskList, Context context) {
        this.taskList = taskList;
        this.context = context;
        this.sparseBooleanArray = new SparseBooleanArray(taskList.size());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyler_single_task_item,
                parent, false);
        ViewHolder holder = new ViewHolder(view);

        holder.radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int position = holder.getAdapterPosition();
                if (isChecked) {
                    if (lastPosition != -1) {
                        if (lastPosition != position) {
                            sparseBooleanArray.put(lastPosition, false); // 覆盖原来的 key-value
                            notifyItemChanged(lastPosition);
                            sparseBooleanArray.put(position, true); // 覆盖原来的 key-value
                            notifyItemChanged(position);
                            lastPosition = position;
                        }
                    } else {
                        lastPosition = position;
                        sparseBooleanArray.put(position, true);
                    }
                }
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SingleTask task = taskList.get(position);
        holder.taskName.setText(task.getTaskName());
        holder.radioButton.setChecked(sparseBooleanArray.get(position));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        ShowImageRecyclerAdapter adapter = new ShowImageRecyclerAdapter(task.getImgPath(), context);
        holder.showImgRecyclerView.setLayoutManager(linearLayoutManager);
        holder.showImgRecyclerView.setAdapter(adapter);
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView taskName;
        RadioButton radioButton;
        RecyclerView showImgRecyclerView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName = (TextView) itemView.findViewById(R.id.task_name);
            radioButton = (RadioButton) itemView.findViewById(R.id.radioButton);
            showImgRecyclerView = (RecyclerView) itemView.findViewById(R.id.recyclerView_show_imgs);
        }
    }
}
