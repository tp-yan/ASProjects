#include<iostream>
#include<sstream>
#include"img.h"
#include"img_factory.h"
#include <jni.h>
#include <random>


#include <backward/hashtable.h>
#include "stc_embed_neon.h"
#include "fileheader.h"
#include "ued_cost.h"
#include "img_jpeg.h"
#include "jpeg_recompress.h"
#include "../ju/ju_cost_model.h"

#include "sha1.h"

extern "C" {
#include "include/ffmpeg.h"
#include "include/libavutil/stegoAlg.h"
}
using namespace std;
typedef unsigned char BYTE;

extern "C"
jstring
Java_com_example_guan_stegwechat_StegoAlgorithm_STCembed(JNIEnv *env, jobject /* this */,
                                                         jstring AllPath, jstring Apppath,
                                                         jbyteArray data,
                                                         jstring pwd, jint flag, jint seed,
                                                         jdouble payload, jint matrixheight,
                                                         jint videoSeed,
                                                         jbyteArray videoRandomKeys) {
    string AllOutPath = "";
    int headlen = sizeof(int) * 8 * 8 + 8;
    int message_bit;
    int start_byte = 0;//嵌入起始位
    int embedlen = 0;   //已嵌入的比特数
    const char *allpath = env->GetStringUTFChars(AllPath, NULL);   //所有图的路径
    const char *password = env->GetStringUTFChars(pwd, NULL);
    string rc_path = env->GetStringUTFChars(Apppath, NULL);
    jbyte *msg_data = (jbyte *) env->GetByteArrayElements(data, 0);
    jsize datasize = env->GetArrayLength(data);
    BYTE *byte_data = (BYTE *) msg_data;
    BYTE *embed_data;
    int data_len = (int) datasize;
    string user_id;
    bool is_last = 0;

    //////////获取系统时间及随机数///////////////
    int ttt = 0;
    int time_sys = time(NULL);
    srand(time_sys);

    // 视频密钥
    char msgdata[40] = {0};
    jbyte *video_random_keys = (jbyte *) env->GetByteArrayElements(videoRandomKeys, NULL);
    int video_rand = videoSeed; // 视频随机数
    for (int i = 0; i < 40; ++i) {
        msgdata[i] = video_random_keys[i];
    }

    ///////////video_random///////////////////
    /*
    char c_inputVideoPath[500] = {0};
    sprintf(c_inputVideoPath, "%s", "/storage/emulated/0/index_pro/345-embed100M0729.mkv");//隐写视频位置
    char c_indexfilePath[500] = {0};
    sprintf(c_indexfilePath, "%s",
            "/storage/emulated/0/index_pro/IframesIndex0724.txt");//视频I帧对应的索引文本目录
    extractMsgfromIndex(c_inputVideoPath, c_indexfilePath, video_rand, 40, msgdata);
    /////////////////////////////////////////////////////////////////////////////////////////////
    //char msgdata[40]={0};
     */
    /////sha1///////
    SHA1 sha1;

    char sha1_buffer[41];

    sha1.SHA_GO(password, sha1_buffer);
    ///////////////////
    string path[50];    //所有图的路径
    string path_rc[50];    //所有压缩图的路径
    path->clear();
    path_rc->clear();
    int j = 0;
    for (int i = 0; i < strlen(allpath); i++) {
        if (i + 1 < strlen(allpath) && allpath[i] == '|' && allpath[i + 1] == '|') {
            j++;
            i++;
        } else {
            path[j] += allpath[i];
        }
    }
    int PicSize = j + 1;    //图片总数

    //图片压缩
    int location_separator = 0;
    int location_name = 0;
    for (int k = 0; k < PicSize; k++) {
        const char *jpeg_inputpath = path[k].c_str();
        location_separator = path[k].find_last_of('/');
        location_name = path[k].find_last_of('.');
        string outputpath = "";
        outputpath += rc_path;
        for (int i = location_separator; i < location_name; i++) {
            outputpath += jpeg_inputpath[i];
        }
        outputpath += "_rc.jpg";
        path_rc[k] = outputpath;
    }
    int tb_w = 2048, tb_h = 1536;
    int quality = 85;
    for (int i = 0; i < PicSize; ++i) {
        bool result = resize_and_compress_single(path[i].c_str(), path_rc[i].c_str(), tb_w, tb_h,
                                                 quality);
        if (!result) {
            string compresserror = "compresserror";
            return env->NewStringUTF(compresserror.c_str());
        }
    }


    message_bit = data_len * 8;


    // 实现多图嵌入
    for (int k = 0; k < PicSize; k++) {
        const char *rc_inputpath = path_rc[k].c_str();
        const char *jpeg_inputpath = path[k].c_str();
        string outputpath = "";
        for (int i = 0; i < strlen(jpeg_inputpath); i++) {
            if (jpeg_inputpath[i] == '.')
                break;
            else outputpath += jpeg_inputpath[i];
        }
        outputpath += "_rc_STC.jpg";
        const char *jpeg_outputpath = outputpath.c_str();

        img *img_ptr = img_factory::createImage(rc_inputpath, seed, 0, true);
        if (!img_ptr) {
            continue;
        }
        img_jpeg *img_jpeg_ptr = (img_jpeg *) img_ptr;

        ///获取图像的width以及height
        int img_jpeg_width = img_jpeg_ptr->getWidth();
        int img_jpeg_height = img_jpeg_ptr->getHeight();
        ///获取图像基于该通道的coeff
        vector<mat2D<int> *> coeff_array = img_jpeg_ptr->getElementMatrix();
        ///获取图像的有效载体
        int cover_size = img_jpeg_ptr->getSize();
        int max_msglenth = (cover_size - headlen) * payload;
        //真正的嵌入bit数
        int real_length =
                (message_bit - embedlen) > max_msglenth ? max_msglenth : (message_bit - embedlen);
        if (((message_bit - embedlen) > max_msglenth) && (k == PicSize - 1)) {
            for (int i = 0; i < PicSize; ++i) {
                if (remove(path_rc[i].c_str()) == 0)
                    continue;
                else {
                    string errorcallback = "delete_error";
                    return env->NewStringUTF(errorcallback.c_str());
                }
            }
            AllOutPath += "error";
            return env->NewStringUTF(AllOutPath.c_str());
        }

        char *messagebit = new char[real_length / 8 * 8];
        start_byte = embedlen / 8;
        embed_data = byte_data + start_byte;
        for (int i = 0; i < real_length / 8; ++i) {
            char messagesingle = embed_data[i] ^sha1_buffer[i % 40] ^msgdata[i % 40];
            for (int j = 0; j <= 7; ++j) {
                messagebit[i * 8 + j] = (messagesingle >> j) & 0x01;
            }
        }


        int *valid_cover_stc = img_jpeg_ptr->getValidCover();
        //int *valid_cover_mme_ptr = valid_cover_stc;
        char *valid_cover_lsb = new char[cover_size];
        char *stego_lsb = new char[cover_size];           //stego lsb
        for (int i = 0; i < img_jpeg_ptr->getSize(); ++i) {
            //将图像的DCT系数取绝对值，并将最低比特位取出
            valid_cover_lsb[i] = abs(valid_cover_stc[i]) & 0x0001;
        }
        ///获取图像的Y通道
        int channelSize = img_jpeg_width * img_jpeg_height;
        int *cover_Y = new int[channelSize];
        for (int i = 0; i < channelSize; i++) {
            int row = i / img_jpeg_width;
            int col = i % img_jpeg_width;
            cover_Y[i] = coeff_array[0]->Read(row, col);
        }
        memcpy(stego_lsb, valid_cover_lsb, img_jpeg_ptr->getSize() * sizeof(char));
        ///对Y通道进行代价计算
        float *cost_Y = new float[channelSize];
        int rows = img_jpeg_height;
        int cols = img_jpeg_width;
        float gia = 1.3;
        float gir = 1.0;
        float *valid_cover_cost = new float[cover_size];
        vector<int> indexRand = img_jpeg_ptr->getValidCoverIndex();//这里的随机会导致用pc端不同步，待改

        // 开始时间
        timeval start, end;
        gettimeofday(&start, NULL);
        // 计算代价
        ju_cost_model jucost(img_jpeg_ptr, valid_cover_cost, 2);

        // 结束时间
        gettimeofday(&end, NULL);
        ttt = 1000 * (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000;
        if ((embedlen + floor(real_length / 8) * 8) >= message_bit)
            is_last = 1;
        //设置文件的头部信息
        FileHeader fileheader;
        //int headlen = sizeof(int) * 8 * 8 + 8;
        fileheader.task_id = time_sys;            //任务ID字段
        fileheader.video_rand = video_rand;            //视频随机数字段
        fileheader.msgfile = "file";            //秘密信息ID字段
        fileheader.algortype = flag;               //信息格式  1：文本  2：语音  3：图片  4：文件
        fileheader.msglength = real_length / 8;   //消息总长度(byte)
        fileheader.firstlayer = 0;              //第一层消息长度字段
        fileheader.seqnum = k;                  //消息序号
        fileheader.stc_h = matrixheight;        //STC的h参数
        fileheader.covertype = 0;               //有效载体类型
        fileheader.islast = is_last;                  //尾标志

        //获取message的头部信息的bin形式
        int *header_msg = setHeaderdata(fileheader);

        //存储message的头部信息
        for (int i = 0; i < headlen; i++) {
            int bit = header_msg[i];
            if (0 == bit) {
                if (1 == valid_cover_stc[i]) {
                    (valid_cover_stc[i])++;
                } else if (1 == ((valid_cover_stc[i] % 2) + 2) % 2) {
                    (valid_cover_stc[i])--;
                }
            } else {
                if (0 == ((valid_cover_stc[i] % 2) + 2) % 2) {
                    (valid_cover_stc[i])++;
                }
            }
        }
        char *valid_cover_lsb_noheader = &valid_cover_lsb[headlen];
        float *valid_cover_cost_noheader = &valid_cover_cost[headlen];
        char *stego_lsb_noheader = &stego_lsb[headlen];
        double stc_result = stc_embed(valid_cover_lsb_noheader, cover_size - headlen,
                                      messagebit,
                                      (real_length / 8) * 8, valid_cover_cost_noheader,
                                      stego_lsb_noheader, matrixheight);
        // 实际对载体进行修改，当载体为-1时，-1为+1时，+1；其他根据随机数决定加减1
        std::mt19937 gen(110);
        std::uniform_int_distribution<> dist(0, RND_MAX_H);
        for (int i = headlen; i < cover_size; ++i) {
            if (valid_cover_lsb[i] != stego_lsb[i]) {
                if (valid_cover_stc[i] == -1)
                    valid_cover_stc[i] = valid_cover_stc[i] - 1;
                else if (valid_cover_stc[i] == 1)
                    valid_cover_stc[i] = valid_cover_stc[i] + 1;
                else {
                    int yesorno = dist(gen) % 2;
                    if (yesorno == 1)
                        valid_cover_stc[i] = valid_cover_stc[i] + 1;
                    else
                        valid_cover_stc[i] = valid_cover_stc[i] - 1;
                }
            }
        }
        //写回修改后的有效载体
        embedlen += floor(real_length / 8) * 8;
        img_jpeg_ptr->setValidCover(valid_cover_stc);
        ///写回图像数据
        img_jpeg_ptr->write(jpeg_outputpath);
        if (embedlen >= message_bit) {
            AllOutPath += jpeg_outputpath;
            AllOutPath += "||";
            delete[] messagebit;
            //delete[] valid_cover_stc;
            delete img_jpeg_ptr;
            delete[] valid_cover_lsb;
            delete[] cover_Y;
            delete[] cost_Y;
            delete[] valid_cover_cost;
            delete[] stego_lsb;
            break;
        } else {
            AllOutPath += jpeg_outputpath;
            AllOutPath += "||";
        }

        delete[] messagebit;
        //delete[] valid_cover_stc;
        delete img_jpeg_ptr;
        delete[] valid_cover_lsb;
        delete[] cover_Y;
        delete[] cost_Y;
        delete[] valid_cover_cost;
        delete[] stego_lsb;
    }
    for (int i = 0; i < PicSize; ++i) {
        if (remove(path_rc[i].c_str()) == 0)
            continue;
        else {
            string errorcallback = "delete file error";
            return env->NewStringUTF(errorcallback.c_str());
        }

    }

    if (embedlen == message_bit) {
        AllOutPath += "success";
//        stringstream ss;
//        ss<<ttt;
//        AllOutPath += ss.str();
        return env->NewStringUTF(AllOutPath.c_str());
    } else {
//        AllOutPath += "missing image";
        AllOutPath += "error";
        return env->NewStringUTF(AllOutPath.c_str());
    }
}