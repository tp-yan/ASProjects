#include<iostream>
#include<sstream>
#include"img.h"
#include"img_factory.h"
#include <jni.h>
#include <random>
#include "stc_embed_neon.h"
#include "fileheader.h"
#include "ued_cost.h"
#include "img_jpeg.h"
#include "jpeg_recompress.h"
#include "../ju/ju_cost_model.h"

using namespace std;
typedef unsigned char BYTE;

extern "C"
jstring
Java_com_example_guan_stegwechat_StegoAlgorithm_STCembed(JNIEnv *env, jobject /* this */,
                                                   jstring AllPath,jbyteArray data, jint flag, jint seed, jdouble payload, jint matrixheight)
{
    string AllOutPath = "";
    int headlen = sizeof(int) * 8 * 8 + 8;
    int message_bit;
    int embedlen = 0;   //已嵌入的比特数
    const char *allpath = env->GetStringUTFChars(AllPath, NULL);   //所有图的路径
    jbyte * msg_data = (jbyte*)env->GetByteArrayElements(data, 0);
    jsize datasize = env->GetArrayLength(data);
    BYTE* byte_data = (BYTE*)msg_data;
    int data_len = (int)datasize;


    string path[50];    //所有图的路径
    string path_rc[50];    //所有压缩图的路径
    path->clear();
    path_rc->clear();
    int j = 0;
    for (int i = 0; i < strlen(allpath); i++) {
        if (i + 1 < strlen(allpath) && allpath[i] == '|' && allpath[i + 1] == '|') {
            j++;
            i++;
        }
        else {
            path[j] += allpath[i];
        }
    }
    int PicSize = j + 1;    //图片总数

    //图片压缩
    string outputpath_rc = "";
    for (int k = 0; k < PicSize; k ++) {
        const char *jpeg_inputpath = path[k].c_str();

        string outputpath = "";
        for (int i = 0; i < strlen(jpeg_inputpath); i++) {
            if (jpeg_inputpath[i] == '.')
                break;
            else outputpath += jpeg_inputpath[i];
        }
        outputpath += "_rc.jpg";
        path_rc[k] = outputpath;
        if(k == PicSize - 1)
        {
            outputpath_rc += outputpath;
        } else
        {
            outputpath_rc += outputpath;
            outputpath_rc += "||";
        }
    }
    int tb_w = 2048, tb_h =1536;
    int quality = 85;
    for(int i = 0; i < PicSize; ++i)
    {
        bool result = resize_and_compress_single(path[i].c_str(), path_rc[i].c_str(), tb_w, tb_h, quality);
        if(!result)
        {
            string compresserror = "compresserror";
            return env->NewStringUTF(compresserror.c_str());
        }

    }


    message_bit = data_len * 8;

    int ttt=0;
    // 实现多图嵌入
    for (int k = 0; k < PicSize; k ++)
    {
        const char *jpeg_inputpath = path_rc[k].c_str();

        string outputpath = "";
        for (int i = 0; i < strlen(jpeg_inputpath); i++) {
            if (jpeg_inputpath[i] == '.')
                break;
            else outputpath += jpeg_inputpath[i];
        }
        outputpath += "_STC.jpg";
        const char *jpeg_outputpath = outputpath.c_str();

        img *img_ptr = img_factory::createImage(jpeg_inputpath, seed, 0, true);
        if(!img_ptr) {
            continue;
        }
        img_jpeg* img_jpeg_ptr = (img_jpeg*)img_ptr;

        ///获取图像的width以及height
        int img_jpeg_width = img_jpeg_ptr->getWidth();
        int img_jpeg_height = img_jpeg_ptr->getHeight();
        ///获取图像基于该通道的coeff
        vector<mat2D<int> *> coeff_array = img_jpeg_ptr->getElementMatrix();
        ///获取图像的有效载体
        int cover_size = img_jpeg_ptr->getSize();
        int max_msglenth = (cover_size-headlen)* payload;
        //真正的嵌入bit数
        int real_length = (message_bit - embedlen) > max_msglenth ? max_msglenth : (message_bit - embedlen);
        if(((message_bit - embedlen) > max_msglenth)&&(k=PicSize-1))
        {
            for(int i = 0; i < PicSize; ++i)
            {
                if(remove(path_rc[i].c_str()) == 0)
                    continue;
                else
                {
                    string errorcallback = "delete_error";
                    return env->NewStringUTF(errorcallback.c_str());
                }
            }
            AllOutPath += "error";
            return env->NewStringUTF(AllOutPath.c_str());
        }

        char * messagebit = new char[real_length/8*8];
        for (int i = 0; i < real_length/8; ++i) {
            char messagesingle =byte_data[i];
            for (int j = 0; j <= 7; ++j) {
                messagebit[i * 8 + j] = (messagesingle >> j) & 0x01;
            }
        }


        int *valid_cover_stc = img_jpeg_ptr->getValidCover();
        //int *valid_cover_mme_ptr = valid_cover_stc;
        char *valid_cover_lsb = new char[cover_size];
        char *stego_lsb = new char[cover_size];           //stego lsb
        for (int i = 0; i < img_jpeg_ptr->getSize(); ++i) {
                //将图像的DCT系数取绝对值，并将最低比特位取出
            valid_cover_lsb[i] = abs(valid_cover_stc[i]) & 0x0001;
        }
        ///获取图像的Y通道
        int channelSize = img_jpeg_width * img_jpeg_height;
        int *cover_Y = new int[channelSize];
        for (int i = 0; i < channelSize; i++)
        {
            int row = i / img_jpeg_width;
            int col = i % img_jpeg_width;
            cover_Y[i] = coeff_array[0]->Read(row, col);
        }
        memcpy(stego_lsb, valid_cover_lsb, img_jpeg_ptr->getSize() * sizeof(char));
        ///对Y通道进行代价计算
        float *cost_Y = new float[channelSize];
        int rows = img_jpeg_height;
        int cols = img_jpeg_width;
        float gia = 1.3;
        float gir = 1.0;
        float *valid_cover_cost = new float[cover_size];
        vector<int> indexRand = img_jpeg_ptr->getValidCoverIndex();//这里的随机会导致用pc端不同步，待改

        // 开始时间
        timeval start, end;
        gettimeofday(&start, NULL);
        // 计算代价
        ju_cost_model jucost(img_jpeg_ptr,valid_cover_cost,2);

        // 结束时间
        gettimeofday(&end, NULL);
        ttt = 1000*(end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec)/1000;

            //设置文件的头部信息
            FileHeader fileheader;
            //int headlen = sizeof(int) * 8 * 8 + 8;
            fileheader.user_id = "user";            //用户名字段
            fileheader.timestamp = "12";            //时间戳字段
            fileheader.msgfile = "file";            //文件ID字段
            fileheader.algortype = flag;               //信息格式  1：文本  2：语音  3：图片  4：文件
            fileheader.msglength = real_length/8;   //消息总长度(byte)
            fileheader.firstlayer = 0;              //第一层消息长度字段
            fileheader.seqnum = k;                  //消息序号
            fileheader.stc_h = matrixheight;        //STC的h参数
            fileheader.covertype = 0;               //有效载体类型
            fileheader.islast = 1;                  //尾标志

            //获取message的头部信息的bin形式
            int *header_msg = setHeaderdata(fileheader);

            //存储message的头部信息
            for (int i = 0; i < headlen; i++) {
                int bit = header_msg[i];
                if (0 == bit) {
                    if (1 == valid_cover_stc[i]) {
                        (valid_cover_stc[i])++;
                    }
                    else if (1 == ((valid_cover_stc[i] % 2) + 2) % 2) {
                        (valid_cover_stc[i])--;
                    }
                }
                else {
                    if (0 == ((valid_cover_stc[i] % 2) + 2) % 2) {
                        (valid_cover_stc[i])++;
                    }
                }
            }
            char *valid_cover_lsb_noheader = &valid_cover_lsb[headlen];
            float *valid_cover_cost_noheader = &valid_cover_cost[headlen];
            char *stego_lsb_noheader = &stego_lsb[headlen];
            double stc_result = stc_embed(valid_cover_lsb_noheader, cover_size - headlen,
                                          messagebit,
                                          (real_length/8)*8, valid_cover_cost_noheader,
                                          stego_lsb_noheader, matrixheight);
            // 实际对载体进行修改，当载体为-1时，-1为+1时，+1；其他根据随机数决定加减1
            std::mt19937 gen(110);
            std::uniform_int_distribution<> dist(0, RND_MAX_H);
            for (int i = headlen; i < cover_size; ++i) {
                if (valid_cover_lsb[i] != stego_lsb[i]) {
                    if (valid_cover_stc[i] == -1)
                        valid_cover_stc[i] = valid_cover_stc[i] - 1;
                    else if (valid_cover_stc[i] == 1)
                        valid_cover_stc[i] = valid_cover_stc[i] + 1;
                    else {
                        int yesorno = dist(gen) % 2;
                        if (yesorno == 1)
                            valid_cover_stc[i] = valid_cover_stc[i] + 1;
                        else
                            valid_cover_stc[i] = valid_cover_stc[i] - 1;
                    }
                }
            }
            //写回修改后的有效载体
            embedlen += floor(real_length/8)*8;
            img_jpeg_ptr->setValidCover(valid_cover_stc);
            ///写回图像数据
            img_jpeg_ptr->write(jpeg_outputpath);
            if(embedlen >= message_bit)
            {
                AllOutPath += jpeg_outputpath;
                AllOutPath += "||";
                delete[] messagebit;
                //delete[] valid_cover_stc;
                delete img_jpeg_ptr;
                delete[] valid_cover_lsb;
                delete[] cover_Y;
                delete[] cost_Y;
                delete[] valid_cover_cost;
                delete[] stego_lsb;
                break;
            }
            else
            {
                AllOutPath += jpeg_outputpath;
                AllOutPath += "||";
            }

            delete[] messagebit;
            //delete[] valid_cover_stc;
            delete img_jpeg_ptr;
            delete[] valid_cover_lsb;
            delete[] cover_Y;
            delete[] cost_Y;
            delete[] valid_cover_cost;
            delete[] stego_lsb;
        }
    for(int i = 0; i < PicSize; ++i)
    {
        if(remove(path_rc[i].c_str()) == 0)
            continue;
        else
        {
            string errorcallback = "delete file error";
            return env->NewStringUTF(errorcallback.c_str());
        }
    }

    if(embedlen == message_bit)
    {
        AllOutPath += "success";
//        stringstream ss;
//        ss<<ttt;
//        AllOutPath += ss.str();
        return env->NewStringUTF(AllOutPath.c_str());
    }
    else
    {
//        AllOutPath += "missing image";
        AllOutPath += "error";
        return env->NewStringUTF(AllOutPath.c_str());
    }
}

