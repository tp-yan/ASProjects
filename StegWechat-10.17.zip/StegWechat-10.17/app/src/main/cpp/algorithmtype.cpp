#include <string>
#include <jni.h>
#include "fileheader.h"
#include "img_factory.h"
#include "STCextract.h"
#include "sha1.h"
extern "C" {
#include "include/ffmpeg.h"
#include "include/libavutil/stegoAlg.h"
}
#define max_picsize 50
using namespace std;

extern "C"
jbyteArray Java_com_example_guan_stegwechat_StegoAlgorithm_algorithmtype(JNIEnv *env, jobject /* this */,    //byte
                                                           jstring AllPath, jstring pass, jint seed)
{

    const char* allpath = env->GetStringUTFChars(AllPath, NULL);
    const char* password = env->GetStringUTFChars(pass, NULL);
    int length = 0;   //消息总长度(byte)
    int* seq_len;     //每段消息的长度(byte)
    jbyte byte_err[3];
    jbyteArray err_result =env->NewByteArray(3);
    //协议部分
    int magic_num, taskId, video_rand, fileHash, msg_length, algortype, firstlayer, seq_num, stc_h, validCoverType, lastFlag;
    int video_flag=-1;
    char rand_data[40]={0}; ////视频数据随机数
    char** message;     //分段消息
    string path[max_picsize];    //所有图的路径
    path->clear();
    int j = 0;
    int user_id;
    bool initial_id=0;
    int task_total_stego=0;
    /////////sha1///////////////////////
    SHA1 sha1;

    char sha1_buffer[41];

    sha1.SHA_GO(password,sha1_buffer);
    ////////////////////////////


    for(int i = 0;i < strlen(allpath);i ++)
    {
        if(i+1 < strlen(allpath) && allpath[i] == '|' && allpath[i+1] == '|')
        {
            j++;
            i++;
        }
        else
        {
            path[j] += allpath[i];
        }
    }
    int PicSize = j+1;    //图片总数
    message = new char*[PicSize];
    seq_len = new int[PicSize];
    // 多图提取
    for(int i = 0;i < PicSize;i++)
    {
        const char* jpeg_Inputpath = path[i].c_str();
        img *img_jpeg_ptr = img_factory::createImage(jpeg_Inputpath, seed, 0);
        if(!img_jpeg_ptr) continue;
        int *valid_cover_extract = img_jpeg_ptr->getValidCover();
        int valid_cover_extract_len = img_jpeg_ptr->getSize();      //(byte)
        int headerLength = sizeof( int ) * 8 * 8 + 8;   //头部长度  (bit)
        int	*header_msg = new int[headerLength];
        for ( int j = 0; j < headerLength; j ++)
        {
            header_msg[ j ] = valid_cover_extract[ j ] & 0x1;
        }

        convertBackBinary<int>( magic_num,	header_msg + sizeof( int ) * 8 * 0, sizeof( int ) * 8 );
        convertBackBinary<int>( taskId,header_msg + sizeof( int ) * 8 * 1, sizeof( int ) * 8 );
        convertBackBinary<int>( video_rand,header_msg + sizeof( int ) * 8 * 2, sizeof( int ) * 8 );
        convertBackBinary<int>( fileHash,header_msg + sizeof( int ) * 8 * 3, sizeof( int ) * 8 );
        convertBackBinary<int>( algortype,header_msg + sizeof( int ) * 8 * 4, sizeof( int ) * 8 );
        convertBackBinary<int>( msg_length,	header_msg + sizeof( int ) * 8 * 5, sizeof( int ) * 8 );
        convertBackBinary<int>( firstlayer,header_msg + sizeof( int ) * 8 * 6, sizeof( int ) * 8 );
        convertBackBinary<int>( seq_num,header_msg + sizeof( int ) * 8 * 7, sizeof( int ) * 8 );
        convertBackBinary<int>( stc_h,header_msg + sizeof( int ) * 8 * 8, 5 );
        convertBackBinary<int>( validCoverType,header_msg + sizeof( int ) * 8 * 8 + 5, 2 );
        convertBackBinary<int>( lastFlag,header_msg + sizeof( int ) * 8 * 8 + 5 + 2, 1 );
        delete[] header_msg;

        // 判断解析的魔数是否正确
        std::hash<int>	intHash;
        int tmp = ( int ) intHash( taskId + video_rand + fileHash + algortype + msg_length + firstlayer + seq_num + stc_h + validCoverType + lastFlag );

        if ( tmp != magic_num )
        {
            memset(&byte_err,-1,3);
            env->SetByteArrayRegion(err_result, 0,1,byte_err);
            return err_result;
        }

        ///////////video_random///////////////////
        if (video_flag==-1){
            char c_inputVideoPath[500] = {0};
            sprintf(c_inputVideoPath,"%s","/storage/emulated/0/index_pro/345-embed100M0729.mkv");//隐写视频位置
            char c_indexfilePath[500] = {0};
            sprintf(c_indexfilePath,"%s","/storage/emulated/0/index_pro/IframesIndex0724.txt");//视频I帧对应的索引文本目录

            extractMsgfromIndex(c_inputVideoPath, c_indexfilePath, video_rand, 40,rand_data);
            video_flag =1;
        }
        /////////////////////////////////////////////////////////////////////////////////////////////

        if(initial_id==0)
        {
            user_id = taskId;
            initial_id=1;
        }
        else
        {
            if(user_id!=taskId)
            {
                memset(&byte_err,0,3);
                env->SetByteArrayRegion(err_result, 0,1,byte_err);
                return err_result;
            }
        }
        if(lastFlag==1)
            task_total_stego=seq_num+1;
        length += msg_length;
        seq_len[seq_num] = msg_length;

        char* s;
        s = STCextract(msg_length, valid_cover_extract_len, valid_cover_extract+headerLength, stc_h);
        message[seq_num] = new char[msg_length];
        for(int k = 0;k < msg_length;k ++)
        {
            message[seq_num][k] = s[k];
        }
    }
    if(PicSize!=task_total_stego)
    {
        memset(&byte_err,-2,3);
        env->SetByteArrayRegion(err_result, 0,1,byte_err);
        return err_result;
    }
    char* msg = new char[length+2]; //////+2
    int k = 1;
    msg[0]= algortype;
    int index = 0;
    for(int i = 0;i < PicSize;i ++)
    {
        for(int j = 0;j < seq_len[i];j ++)
       {
           msg[k] = message[i][j] ^ sha1_buffer[index%40] ^ rand_data[index%40];
           k++;
           index++;
       }
        index = 0;
    }

    //std::string result(msg);

    jbyte gs_raw_data[length+2];
    memset(&gs_raw_data,0,length+2);
    memcpy(&gs_raw_data,msg,length+1);
    jbyteArray jarrRV =env->NewByteArray(length+2);
    env->SetByteArrayRegion(jarrRV, 0,length+1,gs_raw_data);

    delete [] msg;
    delete [] message;
    delete [] seq_len;

    return jarrRV; //byte

}
