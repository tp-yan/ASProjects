//
// Created by cv on 2019/10/17/0017.
//
#include <jni.h>
#include <string>

extern "C"
{
#include "include/ffmpeg.h"
}

using namespace std;

extern "C"
JNIEXPORT jintArray JNICALL
Java_com_example_guan_stegwechat_service_VideoIntentService_getRandomKey(JNIEnv *env,
                                                                         jobject thiz) {
    //////////获取系统时间及随机数///////////////
    int time_sys = time(NULL);
    srand(time_sys);
    int video_rand = rand();

    char c_inputVideoPath[500] = {0};
    sprintf(c_inputVideoPath, "%s", "/storage/emulated/0/index_pro/345-embed100M0729.mkv");//隐写视频位置
    char c_indexfilePath[500] = {0};
    sprintf(c_indexfilePath, "%s",
            "/storage/emulated/0/index_pro/IframesIndex0724.txt");//视频I帧对应的索引文本目录

    char msgdata[40] = {0}; // 实际存放的是 byte[]
    // 提取密钥
    extractMsgfromIndex(c_inputVideoPath, c_indexfilePath, video_rand, 40, msgdata);

    // 转为 byte[] 返回
//    jbyteArray byteArray = env->NewByteArray(40);
//    env->SetByteArrayRegion(byteArray, 0, 40, (jbyte *) msgdata);
    jint* buffer = new int[41];
    for (int i = 0; i < 40; ++i) {
        buffer[i] = msgdata[i];
    }
    buffer[40] = video_rand;

    jintArray data = env->NewIntArray(41);
    env->SetIntArrayRegion(data,0,41,buffer); // 从0开始，长度为41

    return data;
}