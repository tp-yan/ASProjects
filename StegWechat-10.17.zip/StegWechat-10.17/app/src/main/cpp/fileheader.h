//
// Created by lenovo on 2016/11/22.
//

#ifndef IH_FILEHEADER_H
#define IH_FILEHEADER_H
#include<string>
struct FileHeader
{
    std::string magic_num;    //头部校验字段
    std::string msgfile;      //文件ID字段
    int task_id;      //任务ID字段
    int video_rand;    //时间戳字段
    int algortype;            //算法类型  0：LSB  1：F5  2：MME  3：STC
    int msglength;            //消息总长度
    int firstlayer;           //第一层消息长度字段
    int seqnum;               //消息序号
    int stc_h;                //STC的h参数
    int covertype;            //有效载体类型
    bool islast;              //尾标志
};

int* setHeaderdata(FileHeader fileheader);

template <typename T>
inline void convertBackBinary( T &dest, int *src, int size=0 ){
    if( size == 0 ){
        size = sizeof(T)*8;
    }
    if( size > sizeof(T)*8 ){
        //throw std::exception( "Size is out of the range of the destination type." );
    }

    dest = 0;
    for( int i=std::min<int>(sizeof(T)*8, size); i>0; --i ){
        dest = ( dest << 1 ) + src[i-1];
    }
}

template <typename T>
inline void convertBinary( const T src, int *dest, int size=0 )
{
    if( size == 0 ){
        size = sizeof(T)*8;
    }
    int i = 0;
    for( ; i<std::min<int>(sizeof(T)*8, size); ++i ){
        dest[i] = (src >> i) & 0x0001;
    }

    for( ; i<size; ++i ){
        dest[i] = 0;
    }
}


#endif //IH_FILEHEADER_H
