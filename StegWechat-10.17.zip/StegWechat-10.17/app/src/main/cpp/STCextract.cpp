#include <iostream>
#include <jni.h>
#include "img.h"
#include "stc_extract_c.h"
using namespace std;
char* STCextract(int messageLen, int valid_cover_extract_len,
                 int *valid_cover_noheader, int matrixheight)
{
    int valid_size = valid_cover_extract_len;
    int *valid_cover_stc = valid_cover_noheader;
    int headlen =  sizeof( int ) * 8 * 8 + 8;
    char * valid_cover_lsb = new char[valid_size - headlen];
    for(int  i = 0; i < valid_size - headlen  ; ++i)
    {
        //将图像的DCT系数取绝对值，并将最低比特位取出
        valid_cover_lsb[i] = abs(valid_cover_stc[i]&0x0001);
    }
    int message_bit_length = messageLen*8;
    char * message_bit = new char[message_bit_length];

    int exresult = stc_extract(valid_cover_lsb, valid_size-headlen, message_bit , message_bit_length, matrixheight );
    // 将提取出的 bit信息转换为ascii码
    int message_length = message_bit_length/8;
    char *message = new char[message_length];

    for(int i = 0; i< message_length; ++i)
    {
        int linshi = 0;
        int mylin = 0;
        for(int j = 0; j <= 7; ++j )
        {
            mylin = ((int)message_bit[i*8+j])<<j;
            linshi = linshi+ mylin;
        }
        message[i] = linshi;

    }

    delete[] message_bit;
    delete [] valid_cover_lsb;
    return message;
}

