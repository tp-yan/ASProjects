#ifndef STC_EXTRACT_C_H
#define STC_EXTRACT_C_H

#include "common.h"

/* Inputs:
	stego - the binary stego vector
	stegolength - the length of the stego vector
	message - pointer to an array of legth 'messagelength' to receive the extracted message
	messagelegth - the length of the embedded message
	constr_height - the constraint height of the matrix used for embedding the message

Return values:
	0 on succes, -1 on error
*/

int stc_extract(const char *stego, int stegolength, char *message, int messagelength, int constr_height = 10);
template <typename T>
inline void convertBinary( const T src, int *dest, int size=0 );
template <typename T>
inline void convertBackBinary( T &dest, int *src, int size=0 );
#endif
