//
// Created by zzz on 2016/11/1.
//

#ifndef MYAPPLICATIONC11_STC_EMBED_NEON_H
#define MYAPPLICATIONC11_STC_EMBED_NEON_H
#include "common.h"
double stc_embed( const char *cover, int coverlength, const char *message, int messagelength,
                  const float *costs, char *stego, int matrixheight = 10 );
#endif //MYAPPLICATIONC11_STC_EMBED_NEON_H
