#include <iostream>
using namespace std;
#ifndef IH_BUILDXML_H
#define IH_BUILDXML_H
void writexml(const char* task_id, const char* timestamp,const char* msgfile, int finishbits, int leftbits);
#endif //IH_BUILDXML_H
