#ifndef __EMBED_TASK_INFO_H__
#define __EMBED_TASK_INFO_H__

#include <iostream>
// Ƕ������
class embed_task_info {
public:
	std::string coverFile;
	std::string stegoFile;
	std::string msgFile;
	int			h;
	int			seed;
	float		payload;
	float		realPayload;	// ʵ��Ƕ�븺����
	size_t		realMsgBits;	// ʵ��Ƕ��bit��

	//COST_TYPE	method;
	//CODE_TYPE	coder;

public:
	embed_task_info() :
			coverFile(""),
        stegoFile(""), 
        msgFile(""), 
        h(0),
        //seed(0), 
        seed(0),
        payload(0), 
        realPayload(0), 
        realMsgBits(0), 
        //method(COST_TYPE::COST_TYPE_UNKNOWN),
        //coder(CODE_TYPE::CODE_TYPE_STC){}

	embed_task_info(const embed_task_info & info)
	{
		coverFile = info.coverFile;
		stegoFile = info.stegoFile;
		msgFile = info.msgFile;
		h = info.h;
		seed = info.seed;
		payload = info.payload;
		realPayload = info.realPayload;
		realMsgBits = info.realMsgBits;
		//this->method = info.method;
		//this->coder = info.coder;
	}

public:
	inline embed_task_info & operator=( const embed_task_info &rop ) {
		if ( this == &rop ) {
			return *this;
		}

		this->coverFile = rop.coverFile;
		this->stegoFile = rop.stegoFile;
		this->msgFile = rop.msgFile;
		this->h = rop.h;
		this->seed = rop.seed;
		this->payload = rop.payload;
		this->realPayload = rop.realPayload;
		this->realMsgBits = rop.realMsgBits;
		//this->method = rop.method;
		//this->coder = rop.coder;
	
		return ( *this );
	}
};

#endif