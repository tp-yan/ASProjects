//
// Created by zzz on 2018/8/16.
//

#ifndef IH_JPEG_RECOMPRESS_H
#define IH_JPEG_RECOMPRESS_H
const char* resize_and_comress_all(const char* inputFile, int upwith, int upheight,int quality);
bool resize_and_compress_single(const char* inputFile, const char* outputFile, int tb_w, int tb_h, int quality);
#endif //IH_JPEG_RECOMPRESS_H
