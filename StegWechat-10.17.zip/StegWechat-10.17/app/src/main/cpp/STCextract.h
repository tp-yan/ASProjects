#ifndef IH_STCEXTRACT_H
#define IH_STCEXTRACT_H
char* STCextract(int messageLen, int valid_cover_extract_len,
                 int *valid_cover_noheader, int matrixheight);
#endif //IH_STCEXTRACT_H
