#include <string>
#include "fileheader.h"
using namespace std;

int* setHeaderdata(FileHeader fileheader)
{
    int headerLength = sizeof( int ) * 8 * 8 + 8;
    std::hash<std::string>	strHash;

    int	fileHash = ( int ) strHash( fileheader.msgfile );
    int	lastflag =  fileheader.islast ? 1 : 0;

    std::hash<int>	intHash;
    int	magicNumber = ( int ) intHash( fileheader.task_id + fileheader.video_rand + fileHash +   fileheader.algortype +  fileheader.msglength +  fileheader.firstlayer +  fileheader.seqnum +  fileheader.stc_h +  fileheader.covertype + lastflag );
    int	*header_msg = new int[ headerLength ];
    convertBinary<int>( magicNumber, header_msg + sizeof( int ) * 8 * 0, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.task_id, header_msg + sizeof( int ) * 8 * 1, sizeof( int ) * 8 );
    convertBinary<int>(  fileheader.video_rand, header_msg + sizeof( int ) * 8 * 2, sizeof( int ) * 8 );
    convertBinary<int>( fileHash, header_msg + sizeof( int ) * 8 * 3, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.algortype, header_msg + sizeof( int ) * 8 * 4, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.msglength, header_msg + sizeof( int ) * 8 * 5, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.firstlayer, header_msg + sizeof( int ) * 8 * 6, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.seqnum, header_msg + sizeof( int ) * 8 * 7, sizeof( int ) * 8 );
    convertBinary<int>( fileheader.stc_h, header_msg + sizeof( int ) * 8 * 8, 5 );
    convertBinary<int>( fileheader.covertype, header_msg + sizeof( int ) * 8 * 8 + 5, 2 );
    convertBinary<int>( lastflag, header_msg + sizeof( int ) * 8 * 8 + 5 + 2, 1 );
    return header_msg;
}













