#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cstdio>
#include "stc_extract_c.h"

int stc_extract_inner(const char *stego, int stegolength, char *message, int messagelength, int matrixheight, bool debug = false )
{
	int i, j, k, index, index2, base, height;
	
	char *binmat[2];
	int *matrices, *widths;

	height = matrixheight;

    // �����Ϣ���Ȼ�����һ��С����ĸ߶�
    // �� height Ϊ��Ϣ���ȵĴ�С
    if ( height > messagelength ) {
        height = messagelength;
    }

	if(matrixheight > 31) {
		fprintf(stderr, "Submatrix height must not exceed 31.");
		return -1;
	}

    // С���� ��������ͬ����, ��������β��ȫ�� 1, ��ֻ�� ( 1 << ( matrixheight - 2 ) ����ȡֵ
    while ( ( 1 << ( matrixheight - 2 ) ) < ceil( 1.0f * stegolength / messagelength ) ) {
        stegolength >>= 1;
    }

	{
		double invalpha;
		int shorter, longer, worm;
		unsigned int *columns[2];

		matrices = (int *)malloc(messagelength * sizeof(int));
		widths = (int *)malloc(messagelength * sizeof(int));

		invalpha = (double)stegolength / messagelength;
		if(invalpha < 1) {
			fprintf(stderr, "The message cannot be longer than the stego object.\n");
			return -1;
		}
		shorter = (int)floor(invalpha);
		longer = (int)ceil(invalpha);
		if((columns[0] = getMatrix(shorter, matrixheight)) == NULL) {
			free(widths);
			free(matrices);
			return -1;
		}
		if((columns[1] = getMatrix(longer, matrixheight)) == NULL) {
			free(columns[0]);
			free(widths);
			free(matrices);
			return -1;
		}

		worm = 0;
		for(i = 0; i < messagelength; i++) {
			if(worm + longer <= (i + 1) * invalpha + 0.5) {
				matrices[i] = 1;
				widths[i] = longer;
				worm += longer;
			} else {
				matrices[i] = 0;
				widths[i] = shorter;
				worm += shorter;
			}
		}
		//binmat[0] = new char[shorter * matrixheight * sizeof(char)];
		//binmat[0] = new char[longer * matrixheight * sizeof(char)];
		binmat[0] = (char*)malloc(shorter * matrixheight * sizeof(char));
		binmat[1] = (char*)malloc(longer * matrixheight * sizeof(char));
		for(i = 0, index = 0; i < shorter; i++) {
			for(j = 0; j < matrixheight; j++, index++) {
				binmat[0][index] = (columns[0][i] & (1 << j)) ? 1 : 0;
			}
		}
		for(i = 0, index = 0; i < longer; i++) {
			for(j = 0; j < matrixheight; j++, index++) {
				binmat[1][index] = (columns[1][i] & (1 << j)) ? 1 : 0;
			}
		}
		free(columns[0]);
		free(columns[1]);
	}

	for(i = 0; i < messagelength; i++) {
		message[i] = 0;
	}

	for(index = 0, index2 = 0; index2 < messagelength; index2++) {
		for(k = 0, base = 0; k < widths[index2]; k++, index++, base += matrixheight) {
			if(stego[index]) {
				for(i = 0; i < height; i++) {
					message[index2 + i] ^= binmat[matrices[index2]][base + i];
				}
			}
		}
		if(messagelength - index2 <= matrixheight)
			height--;
	}

	free(matrices);
	free(widths);
	free(binmat[0]);
	free(binmat[1]);

	return 0;
}


int stc_extract( const char *stego, int stegolength, char *message, int messagelength, int matrixheight ) {
    int sections = 0;
    int stego_sec = 0;
    int msg_sec = 0;

    section_policy( stegolength, messagelength, matrixheight, sections, stego_sec, msg_sec );

    for ( int i = 0; i < sections; ++i ) {
        int stego_sec_len = stego_sec;
        int msg_sec_len = msg_sec;

        bool debug = false;
        if ( ( i + 1 ) * stego_sec > stegolength ) {
            stego_sec_len = stegolength - i * stego_sec;
        }

        if ( ( i + 1 ) * msg_sec > messagelength ) {
            debug = true;
            msg_sec_len = messagelength - i * msg_sec;
        }

        if ( stego_sec_len <= 0 || msg_sec_len <= 0 ) {
            continue;
        }
        stc_extract_inner( stego + i * stego_sec, stego_sec_len, message + i * msg_sec, msg_sec_len, matrixheight, debug );
    }

    //// ���һ�ε�������
    //int last = ( sections - 1 );
    //int stego_sec_len_last = stegolength - last * stego_sec;
    //int msg_sec_len_last = messagelength - last * msg_sec;;

    //stc_extract_inner( stego + last * stego_sec, stego_sec_len_last, message + last * msg_sec, msg_sec_len_last, matrixheight );

    return 0;
}