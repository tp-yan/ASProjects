#ifndef COMMON_H
#define COMMON_H
#include <arm_neon.h>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <math.h>
#define  RND_MAX_H 0x7fff
// ��Ӧ�γ� Ϊ 2 ^ ( 27 + 3 - h )
const static int MAX_SECTION_MEMORY = 21;

//typedef unsigned int u32;
//typedef unsigned short u16;
//typedef unsigned char u8;

extern unsigned int mats[];

/* Simple class for throwing exceptions
The following error_ids are in use:
1 = Submatrix height must not exceed 31.
2 = Not enough memory.
3 = The message cannot be longer than the cover object.
4 = No solution exists. - This happen when there are too many Inf values in cost vector and thus the solution does not exist due to sparse parity-check matrix.
5 = Price vector limit exceeded. - There is a limit to cost elements when you use integer version of the algorithm. Try to use costs in double.
6 = Maximum number of trials in layered construction exceeded.
7 = Error when generate submatrix H
*/


class stc_exception : public std::exception {
public:
    stc_exception( std::string message, unsigned int error_id ) {
        this->message = message;
        this->error_id = error_id;
    }

    virtual ~stc_exception() throw( ) {}

    virtual const char* what() const throw( ) {
        return message.c_str();
    }
    unsigned int error_id;

private:
    std::string message;
};

unsigned int *getMatrix( int width, int height );
void *aligned_malloc( unsigned int bytes, int align );
void aligned_free( void *vptr );
int get_hamming_matrix( const double payload );
void section_policy( const int coverLen, const int msgLen, const int stc_h, int &sections, int &cover_section_len, int &msg_section_len );
// for permute
float32x4_t VectorSwizzle(float32x4_t V1,float32x4_t V2,uint32_t PermuteX, uint32_t PermuteY, uint32_t PermuteZ, uint32_t PermuteW);
uint32_t vmaskq_u32(uint32x4_t CR);
#endif
