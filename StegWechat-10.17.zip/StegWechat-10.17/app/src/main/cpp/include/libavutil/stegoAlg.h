#ifndef STEGOALG_H
#define STEGOALG_H

#include <stdint.h>
#include <time.h>

enum TaskType
{
	TASK_TYPE_EXTRACT,
	TASK_TYPE_DEPROTOCOL,
	TASK_TYPE_VIDEOCUT,
};

enum StegoAlgType
{
	STEGOALG_TYPE_DCT,
};

typedef struct TaskParams
{
	enum TaskType taskType;

	enum StegoAlgType stegoAlgType;

	int isLastDecodePhase;	// used when extracting msg

	char *msg;
	int64_t msgLen;			// in bytes

	int64_t startBit;		// the index of msg bit where embedding (or extraction) starts
	int64_t curBit;			// the index of the current msg bit to be processed (embeded or extracted)
	int64_t endBit;			// used when extracting msg
	double maxPayload;		// msg file size / video file size 
	int64_t maxAvailBitNum; // the maximum number of msg bits to be embedded (extracted)


    /*DCT_INDEX*/
	int64_t startByte;//the index of msg Byte where extraction starts
	int64_t ByteLen;//the length of msg Byte
	int64_t msgcurBit;//the current msg bit extracted (distinguish curbit)
	int64_t isnearestIFrame;//determine whether it is the nearest I frame by index before extraction
	int64_t isfirstIframe;//whether it is the first I frame in the cut-video
	char NameLog[100];//name of the log file
	char NameMsg[100];//name of the msg file
	int overIframIndex; //the sequence number corresponding to the index of the first I frame of the cut-video
	int overmessageLenth;//
	/*DCT_INDEX*/

	double videoBitrate;	// kb/s
	double framerate;

	char *coverVideoPath;
	char *stegoVideoPath;
	int64_t coverVideoSize;
	time_t starttime;
	time_t indextime;
	time_t endtime;

	void *privData;
}TaskParams;

/* ====================== Embed Parameters ==================== */
/*deleted */
/* ====================== Embed Parameters ==================== */

/* ====================== Extract Parameters ==================== */
/*deleted */


typedef struct ExtractParams_DCT
{
	int dctThresh;
	int dctindexThresh;
	int dctEmbedInterval;
	int dctEmbedCount;
	/*BY YJC_DCT_INDEX*/
	int  IframeTotalNumber;//the number of all embed index I frame
	int  IframeCount;//the sequence number of current
	int  *IframeIndex;//the index embedded in I frame
	char GopStartBit[32];//the bit of index value
	long GopStartByte;//the index value extracted from I frame
	int GopStartBytecurBit;//the sequence number of index-bit extracted,value from 0 to 31(4 bytes)
	int Framecurrent;//current frame number
	/*BY YJC_DCT_INDEX*/
	uint8_t *scantable;
}ExtractParams_DCT;



/* ====================== Extract Parameters ==================== */

extern TaskParams taskParams;
extern ExtractParams_DCT extractParams_DCT;
#endif
