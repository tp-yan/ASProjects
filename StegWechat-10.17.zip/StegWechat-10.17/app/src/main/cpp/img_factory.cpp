#include "img_factory.h"
#include "img_jpeg.h"
#include"img.h"



img *img_factory::createImage( const char *filename, int seed, int headLength ,bool loadSpatial) {
     img *img = nullptr;
	 std::string lowerExt = "";

//	 char *endptr = new char[strlen(filename)+ 1];
//	 strcpy(endptr, filename);
//	 int len_endptr = strlen(endptr);
//	 while (len_endptr >0)
//	 {
//		 if (*endptr == '.')
//		 {
//		 	 do
//		  	 {
//			 	 lowerExt += *endptr;
//				 endptr++;
//				 len_endptr--;
//			 } while (len_endptr >0);
//		 }
//			 endptr++;
//			 len_endptr--;
//	 }

	std::string sfile(filename);
	int pos = sfile.find_last_of('.');
	lowerExt = sfile.substr(pos);

    if ( lowerExt == ".jpg" || lowerExt == ".jpeg" || lowerExt == ".JPG"|| lowerExt == ".JPEG")
	  {
         img = new img_jpeg( filename, seed, headLength,loadSpatial);
      }
	else 
	  {
         //throw std::exception( "Only JPEG are supported" );
      }

    return img;
}


/// <summary>
///
/// </summary>
/// <param name="filename"></param>
/// <returns></returns>
ImageDomain img_factory::getImageDomain( const char *filename ) {
    std::string lowerExt = "";

	char *endptr = new char[strlen(filename) + 1];
	strcpy(endptr, filename);
	int len_endptr = strlen(endptr);
	while (len_endptr >0)
	{
		if (*endptr == '.')
		{
			do
			{
				lowerExt += *endptr;
				endptr++;
				len_endptr--;
			} while (len_endptr >0);
		}
		endptr++;
		len_endptr--;
	}

    if ( lowerExt == ".jpg" || lowerExt == ".jpeg" || lowerExt == ".JPG"|| lowerExt == ".JPEG") {
        return ImageDomain::JPEG;
    } else {
        return ImageDomain::UNKNOWN;
    }
}