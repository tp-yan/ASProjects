#ifndef UED_COST_H
#define UED_COST_H
#include<vector>
#include <malloc.h>
#include<cmath>
#include<thread>
using namespace std;

void uedThread(int img_jpeg_width, int cover_size, const int *cover_Y, int rows, int cols, float gia,
               float gir, float *valid_cover_cost, vector<int> indexRand, int threadId,int threadNums) {
    for (int i = threadId; i < cover_size; i+=threadNums) {
        int iidex = indexRand.at(i);
        int row = iidex / img_jpeg_width;
        int col = iidex % img_jpeg_width;
        float c = abs(cover_Y[iidex]);
        float dia = 0.0;
        float dir = 0.0;
        float p_1 = 0.0;
        float p_8 = 0.0;
        float p_total = 0.0;
        //计算  1/|c| + |dia| + |gia|
        //step 1
        for (int j = -1; j < 2; j += 2) {
            //块内上下
            if ((row + j) < 0 || (row + j) >= rows)
                dia = 0;
            else
                dia = abs(cover_Y[iidex + j * img_jpeg_width]);
            p_total = 1 / (c + dia + gia);
            //块内左右
            if ((col + j) < 0 || (col + j) >= cols)
                dia = 0;
            else
                dia = abs(cover_Y[iidex + j]);
            p_total = p_total + 1 / (c + dia + gia);
        }
        for (int j = -8; j < 9; j += 16) {
            //块间上下
            if ((row + j) < 0 || (row + j) >= rows)
                dia = 0;
            else
                dia = abs(cover_Y[iidex + j * img_jpeg_width]);
            p_total = p_total + 1 / (c + dia + gir);
            //块间左右
            if ((col + j) < 0 || (col + j) >= cols)
                dia = 0;
            else
                dia = abs(cover_Y[iidex + j]);
            p_total = p_total + 1 / (c + dia + gir);
        }
        valid_cover_cost[i] = p_total;
    }
}

void uedCost(int img_jpeg_width, int cover_size, const int *cover_Y, int rows, int cols, float gia,
             float gir, float *valid_cover_cost, vector<int> &indexRand){
    int threadNums = 8;
    std::thread * threads = new std::thread[threadNums];
    for(int threadId = 0;threadId < threadNums;threadId++){
        threads[threadId] = std::thread(&uedThread, img_jpeg_width, cover_size,  cover_Y, rows, cols, gia, gir, valid_cover_cost,
                                   indexRand, threadId, threadNums);
    }
    for(int threadId = 0;threadId < threadNums;threadId++){
        threads[threadId].join();
    }

    delete[] threads;
}

#endif
