#include "buildxml.h"
#include "tinyxml.h"
using namespace std;
void writexml(const char* task_id,const char* timestamp,const char* msgfile, int finishbits, int leftbits)
{
    TiXmlDocument doc;
    TiXmlElement* root = new TiXmlElement("Embedinfo");
    doc.LinkEndChild(root);

    TiXmlElement* element1 = new TiXmlElement("user_id");
    root->LinkEndChild(element1);
    element1->SetAttribute("value", task_id);


    TiXmlElement* element2 = new TiXmlElement("timestamp");  ///元素
    root->LinkEndChild(element2);
    element2->SetAttribute("value", timestamp);


    TiXmlElement* element3 = new TiXmlElement("msgfile");
    root->LinkEndChild(element3);
    element3->SetAttribute("value", msgfile);


    TiXmlElement* element4 = new TiXmlElement("finishbits");
    root->LinkEndChild(element4);
    element4->SetAttribute("value", finishbits);

    TiXmlElement* element5 = new TiXmlElement("leftbits");
    root->LinkEndChild(element5);
    element5->SetAttribute("value", leftbits);

    string xmlfile = "";
    int i;
    for(i = strlen(msgfile)-1; i >= 0; i --)
    {
        if(msgfile[i] == '/')
            break;
    }
    for(int j = 0;j <= i;j ++)
    {
        xmlfile += msgfile[j];
    }
    xmlfile = xmlfile + task_id + ".xml";
    doc.SaveFile(xmlfile.c_str());
    doc.Clear();

}
