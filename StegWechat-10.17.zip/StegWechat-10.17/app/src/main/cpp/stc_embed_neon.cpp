#include "stc_embed_neon.h"
#include <cstring>
#include <cmath>
#include <limits>
#include <sstream>
#include <thread>
#include <chrono>
struct thread_info {
    int threads;
    int sections;
    int cover_section_length;
    int msg_section_length;
};

struct embed_info {
    const char      *cover;
    int             coverlength;
    const char      *message;
    int             messagelength;
    const float    *costs;
    char            *stego;
    int             matrixheight;
};

double stc_embed_inner(const char *cover, int coverlength, const unsigned char *message, int messagelength, const float *costs, char *stego, int matrixheight, bool debug = false )
{
    int height, i, k, l, index, index2, parts, m, sseheight, altm, pathindex;
    unsigned int column, colmask, state;
    double totalprice;

    char *ssedone;
    unsigned int *path, *columns[ 2 ];
    int *matrices, *widths;

    if ( matrixheight > 31 ) throw stc_exception( "Submatrix height must not exceed 31.", 1 );

    height = 1 << matrixheight;  //2^h
    colmask = height - 1;        //2^h-1

    // 消息长度不及小矩阵高度
    if ( matrixheight > messagelength )
    {
        height = 1 << messagelength;
        colmask = height - 1;
    }


    height = ( height + 31 ) & ( ~31 );  //   &00000
    parts = height >> 5;

    if ( stego != NULL )
    {
        path = ( unsigned int* ) malloc( coverlength * parts * sizeof( unsigned int ) );
        std::copy( cover, cover + coverlength, stego );
        if ( path == NULL ) {
            std::stringstream ss;
            ss << "Not enough memory (" << ( unsigned int ) ( coverlength * parts * sizeof( unsigned int ) ) << " byte array could not be allocated).";
            throw stc_exception( ss.str(), 2 );
        }
        pathindex = 0;
    }

    // ????????????????
    while ( (1 << ( matrixheight-2) ) < ceil( 1.0f * coverlength / messagelength ) )
    {
        coverlength >>= 1;
    }

    {
        int shorter, longer, worm;
        double invalpha;

        matrices = ( int * ) malloc( messagelength * sizeof( int ) );
        widths = ( int * ) malloc( messagelength * sizeof( int ) );
        //  n/m
        invalpha = ( double ) coverlength / messagelength;

        //message长度大于cover的长度
        if ( invalpha < 1 ) {
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            throw stc_exception( "The message cannot be longer than the cover object.", 3 );
        }

        shorter = ( int ) floor( invalpha );
        longer = ( int ) ceil( invalpha );
        if ( ( columns[ 0 ] = getMatrix( shorter, matrixheight ) ) == NULL ) {
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            return -1;
        }
        if ( ( columns[ 1 ] = getMatrix( longer, matrixheight ) ) == NULL ) {
            free( columns[ 0 ] );
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            return -1;
        }

        worm = 0;
        for ( i = 0; i < messagelength; i++ )
        {
            if ( worm + longer <= ( i + 1 ) * invalpha + 0.5 )
            {
                matrices[ i ] = 1;
                widths[ i ] = longer;
                worm += longer;
            }
            else
            {
                matrices[ i ] = 0;
                widths[ i ] = shorter;
                worm += shorter;
            }
        }
    }

    int pathindex8 = 0;
    int shift[ 2 ] = { 0, 4 };
    char mask[ 2 ] = { 0xf0, 0x0f };
    float *prices;
    char *path8 = ( char* ) path;
    float *pricevector = ( float* ) costs;
    double total = 0;
    float inf = std::numeric_limits< float >::infinity();

    sseheight = height >> 2;
    ssedone = ( char* ) malloc( sseheight * sizeof( char ) );
    prices = ( float* ) aligned_malloc( height * sizeof( float ), 16 );

    {
        float32x4_t fillval = vdupq_n_f32( inf );//float32x4_t 替换__m128，声明数据；   vdupq_n_f32替换_mm_set1_ps将float32x4_t四个值全部赋值_mm_set1_ps（）
        for ( i = 0; i < height; i += 4 ) {

            vst1q_f32( &prices[ i ], fillval );//vst1q_f32替换_mm_store_ps，将数据从寄存器中存入内存
            ssedone[ i >> 2 ] = 0;
        }
    }

    prices[ 0 ] = 0.0f;



    for ( index = 0, index2 = 0; index2 < messagelength; index2++ ) {
        register float32x4_t c1, c2;

        for ( k = 0; k < widths[ index2 ]; k++, index++ ) {
            column = columns[ matrices[ index2 ] ][ k ] & colmask;

            if ( cover[ index ] == 0 ) {
                c1 = vdupq_n_f32(0);
                c2 = vdupq_n_f32( ( float ) pricevector[ index ] );
            } else {
                c1 = vdupq_n_f32( ( float ) pricevector[ index ] );
                c2 = vdupq_n_f32(0);
            }

            total += pricevector[ index ];

            for ( m = 0; m < sseheight; m++ ) {
                if ( !ssedone[ m ] ) {
                    register float32x4_t v1, v2, v3, v4;
                    register uint32x4_t v5,v6;
                    altm = ( m ^ ( column >> 2 ) );
                    v1 = vld1q_f32( &prices[ m << 2 ] );//vld1q_f32替换 _mm_load_ps，将_mm_load_ps（）中的值四位f32取出放入v1
                    v2 = vld1q_f32( &prices[ altm << 2 ] );
                    v3 = v1;
                    v4 = v2;
                    ssedone[ m ] = 1;
                    ssedone[ altm ] = 1;
                    switch ( column & 3 ) {
                        case 0:
                            break;
                        case 1:
                            v2 = vrev64q_f32( v2 );//相邻数据翻转
                            v3 = vrev64q_f32( v3 );
                            break;
                        case 2:
                            v2 = vextq_f32( v2, v2, 2 );//5,6,7,8-》7,8,5,6
                            v3 = vextq_f32( v3, v3, 2 );
                            break;
                        case 3:
                            //v2 = _mm_shuffle_ps( v2, v2, 0x1b );// 分两步替换
                            v2 = vextq_f32(v2, v2, 2);//5,6,7,8-》7,8,5,6
                            v2 = vrev64q_f32(v2);//7,8,5,6-》8,7,6,5
                            // v3 = _mm_shuffle_ps( v3, v3, 0x1b );
                            v3 = vextq_f32(v3, v3, 2);
                            v3 = vrev64q_f32(v3);
                            break;
                    }
                    v1 = vaddq_f32( v1, c1 );// vaddq_f32 替换_mm_add_ps  相加运算
                    v2 = vaddq_f32( v2, c2 );
                    v3 = vaddq_f32( v3, c2 );
                    v4 = vaddq_f32( v4, c1 );

                    v1 = vminq_f32( v1, v2 );// vminq_f32 替换_mm_min_ps 取最小值运算
                    v4 = vminq_f32( v3, v4 );

                    vst1q_f32( &prices[ m << 2 ], v1 );
                    vst1q_f32( &prices[ altm << 2 ], v4 );

                    if ( stego != NULL ) {
                        v5 = vceqq_f32( v1, v2 );//   vceqq_f32替换_mm_cmpeq_ps，比较v1,v2是否相等，相等则返回NAN，不等返回0
                        v6 = vceqq_f32( v3, v4 );
                        path8[ pathindex8 + ( m >> 1 ) ] = ( path8[ pathindex8 + ( m >> 1 ) ] & mask[ m & 1 ] ) | ( vmaskq_u32( v5 ) << shift[ m
                                                                                                                                               & 1 ] );
                        path8[ pathindex8 + ( altm >> 1 ) ] = ( path8[ pathindex8 + ( altm >> 1 ) ] & mask[ altm & 1 ] ) | ( vmaskq_u32( v6 )
                                                                                                                             << shift[ altm & 1 ] );
                    }
                }
            }

            for ( i = 0; i < sseheight; i++ ) {
                ssedone[ i ] = 0;
            }

            pathindex += parts;
            pathindex8 += parts << 2;
        }

        if ( message[ index2 ] == 0 ) {
            for ( i = 0, l = 0; i < sseheight; i += 2, l += 4 ) {
                //vst1q_f32( &prices[ l ], _mm_shuffle_ps( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 0x88 ) );
                vst1q_f32( &prices[ l ], VectorSwizzle( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 0,2,4,6 ) );
            }
        } else {
            for ( i = 0, l = 0; i < sseheight; i += 2, l += 4 ) {
                vst1q_f32( &prices[ l ], VectorSwizzle( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 1,3,5,7 ) );
            }
        }

        if ( messagelength - index2 <= matrixheight ) colmask >>= 1;

        {
            register float32x4_t fillval = vdupq_n_f32( inf );
            for ( l >>= 2; l < sseheight; l++ ) {
                vst1q_f32( &prices[ l << 2 ], fillval );
            }
        }
    }



    totalprice = prices[ 0 ];

    aligned_free( prices );
    free( ssedone );

    if ( totalprice >= total ) {
        free( matrices );
        free( widths );
        free( columns[ 0 ] );
        free( columns[ 1 ] );
        if ( stego != NULL ) free( path );
        throw stc_exception( "No solution exist.", 4 );
    }

    if ( stego != NULL ) {
        pathindex -= parts;
        index--;
        index2--;
        state = 0;

        // unused
        // int h = messagelength;
        state = 0;
        colmask = 0;
        for ( ; index2 >= 0; index2-- ) {
            for ( k = widths[ index2 ] - 1; k >= 0; k--, index-- ) {
                if ( k == widths[ index2 ] - 1 ) {
                    state = ( state << 1 ) + message[ index2 ];
                    if ( messagelength - index2 <= matrixheight ) colmask = ( colmask << 1 ) | 1;
                }

                if ( path[ pathindex + ( state >> 5 ) ] & ( 1 << ( state & 31 ) ) ) {
                    stego[ index ] = 1;
                    state = state ^ ( columns[ matrices[ index2 ] ][ k ] & colmask );
                } else {
                    stego[ index ] = 0;
                }

                pathindex -= parts;
            }
        }
        free( path );
    }

    free( matrices );
    free( widths );
    free( columns[ 0 ] );
    free( columns[ 1 ] );

    return totalprice;
}

double stc_embed_inner2(const char *cover, int coverlength, const unsigned char *message, int messagelength, const float *costs, char *stego, int matrixheight, bool debug = false )
{
    int height, i, k, l, index, index2, parts, m, sseheight, altm, pathindex;
    unsigned int column, colmask, state;
    double totalprice;

    char *ssedone;
    unsigned int *path, *columns[ 2 ];
    int *matrices, *widths;

    if ( matrixheight > 31 ) throw stc_exception( "Submatrix height must not exceed 31.", 1 );

    height = 1 << matrixheight;  //2^h
    colmask = height - 1;        //2^h-1

    // 消息长度不及小矩阵高度
    if ( matrixheight > messagelength )
    {
        height = 1 << messagelength;
        colmask = height - 1;
    }


    height = ( height + 31 ) & ( ~31 );  //   &00000
    parts = height >> 5;

    if ( stego != NULL )
    {
        path = ( unsigned int* ) malloc( coverlength * parts * sizeof( unsigned int ) );
        std::copy( cover, cover + coverlength, stego );
        if ( path == NULL ) {
            std::stringstream ss;
            ss << "Not enough memory (" << ( unsigned int ) ( coverlength * parts * sizeof( unsigned int ) ) << " byte array could not be allocated).";
            throw stc_exception( ss.str(), 2 );
        }
        pathindex = 0;
    }

    // ????????????????
    while ( (1 << ( matrixheight-2) ) < ceil( 1.0f * coverlength / messagelength ) )
    {
        coverlength >>= 1;
    }

    {
        int shorter, longer, worm;
        double invalpha;

        matrices = ( int * ) malloc( messagelength * sizeof( int ) );
        widths = ( int * ) malloc( messagelength * sizeof( int ) );
        //  n/m
        invalpha = ( double ) coverlength / messagelength;

        //message长度大于cover的长度
        if ( invalpha < 1 ) {
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            throw stc_exception( "The message cannot be longer than the cover object.", 3 );
        }

        shorter = ( int ) floor( invalpha );
        longer = ( int ) ceil( invalpha );
        if ( ( columns[ 0 ] = getMatrix( shorter, matrixheight ) ) == NULL ) {
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            return -1;
        }
        if ( ( columns[ 1 ] = getMatrix( longer, matrixheight ) ) == NULL ) {
            free( columns[ 0 ] );
            free( matrices );
            free( widths );
            if ( stego != NULL ) free( path );
            return -1;
        }

        worm = 0;
        for ( i = 0; i < messagelength; i++ )
        {
            if ( worm + longer <= ( i + 1 ) * invalpha + 0.5 )
            {
                matrices[ i ] = 1;
                widths[ i ] = longer;
                worm += longer;
            }
            else
            {
                matrices[ i ] = 0;
                widths[ i ] = shorter;
                worm += shorter;
            }
        }
    }

    int pathindex8 = 0;
    int shift[ 2 ] = { 0, 4 };
    char mask[ 2 ] = { 0xf0, 0x0f };
    float *prices;
    char *path8 = ( char* ) path;
    float *pricevector = ( float* ) costs;
    double total = 0;
    float inf = std::numeric_limits< float >::infinity();

    sseheight = height >> 2;
    ssedone = ( char* ) malloc( sseheight * sizeof( char ) );
    prices = ( float* ) aligned_malloc( height * sizeof( float ), 16 );

    {
        float32x4_t fillval = vdupq_n_f32( inf );//float32x4_t 替换__m128，声明数据；   vdupq_n_f32替换_mm_set1_ps将float32x4_t四个值全部赋值_mm_set1_ps（）
        for ( i = 0; i < height; i += 4 ) {

            vst1q_f32( &prices[ i ], fillval );//vst1q_f32替换_mm_store_ps，将数据从寄存器中存入内存
            ssedone[ i >> 2 ] = 0;
        }
    }

    prices[ 0 ] = 0.0f;

    for ( index = 0, index2 = 0; index2 < messagelength; index2++ ) {
        register float32x4_t c1, c2;

        for ( k = 0; k < widths[ index2 ]; k++, index++ ) {
            column = columns[ matrices[ index2 ] ][ k ] & colmask;

            if ( cover[ index ] == 0 ) {
                c1 = vdupq_n_f32(0);
                c2 = vdupq_n_f32( ( float ) pricevector[ index ] );
            } else {
                c1 = vdupq_n_f32( ( float ) pricevector[ index ] );
                c2 = vdupq_n_f32(0);
            }

            total += pricevector[ index ];

            for ( m = 0; m < sseheight; m++ ) {
                if ( !ssedone[ m ] ) {
                    register float32x4_t v1, v2, v3, v4;
                    register uint32x4_t v5,v6;
                    altm = ( m ^ ( column >> 2 ) );
                    v1 = vld1q_f32( &prices[ m << 2 ] );//vld1q_f32替换 _mm_load_ps，将_mm_load_ps（）中的值四位f32取出放入v1
                    v2 = vld1q_f32( &prices[ altm << 2 ] );
                    v3 = v1;
                    v4 = v2;
                    ssedone[ m ] = 1;
                    ssedone[ altm ] = 1;
                    switch ( column & 3 ) {
                        case 0:
                            break;
                        case 1:
                            v2 = vrev64q_f32( v2 );//相邻数据翻转
                            v3 = vrev64q_f32( v3 );
                            break;
                        case 2:
                            v2 = vextq_f32( v2, v2, 2 );//5,6,7,8-》7,8,5,6
                            v3 = vextq_f32( v3, v3, 2 );
                            break;
                        case 3:
                            //v2 = _mm_shuffle_ps( v2, v2, 0x1b );// 分两步替换
                            v2 = vextq_f32(v2, v2, 2);//5,6,7,8-》7,8,5,6
                            v2 = vrev64q_f32(v2);//7,8,5,6-》8,7,6,5
                           // v3 = _mm_shuffle_ps( v3, v3, 0x1b );
                            v3 = vextq_f32(v3, v3, 2);
                            v3 = vrev64q_f32(v3);
                            break;
                    }
                    v1 = vaddq_f32( v1, c1 );// vaddq_f32 替换_mm_add_ps  相加运算
                    v2 = vaddq_f32( v2, c2 );
                    v3 = vaddq_f32( v3, c2 );
                    v4 = vaddq_f32( v4, c1 );

                    v1 = vminq_f32( v1, v2 );// vminq_f32 替换_mm_min_ps 取最小值运算
                    v4 = vminq_f32( v3, v4 );

                    vst1q_f32( &prices[ m << 2 ], v1 );
                    vst1q_f32( &prices[ altm << 2 ], v4 );

                    if ( stego != NULL ) {
                        v5 = vceqq_f32( v1, v2 );//   vceqq_f32替换_mm_cmpeq_ps，比较v1,v2是否相等，相等则返回NAN，不等返回0
                        v6 = vceqq_f32( v3, v4 );
                        path8[ pathindex8 + ( m >> 1 ) ] = ( path8[ pathindex8 + ( m >> 1 ) ] & mask[ m & 1 ] ) | ( vmaskq_u32( v5 ) << shift[ m
                                                                                                                                                    & 1 ] );
                        path8[ pathindex8 + ( altm >> 1 ) ] = ( path8[ pathindex8 + ( altm >> 1 ) ] & mask[ altm & 1 ] ) | ( vmaskq_u32( v6 )
                                                                                                                             << shift[ altm & 1 ] );
                    }
                }
            }

            for ( i = 0; i < sseheight; i++ ) {
                ssedone[ i ] = 0;
            }

            pathindex += parts;
            pathindex8 += parts << 2;
        }

        if ( message[ index2 ] == 0 ) {
            for ( i = 0, l = 0; i < sseheight; i += 2, l += 4 ) {
                //vst1q_f32( &prices[ l ], _mm_shuffle_ps( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 0x88 ) );
                vst1q_f32( &prices[ l ], VectorSwizzle( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 0,2,4,6 ) );
            }
        } else {
            for ( i = 0, l = 0; i < sseheight; i += 2, l += 4 ) {
                vst1q_f32( &prices[ l ], VectorSwizzle( vld1q_f32( &prices[ i << 2 ] ), vld1q_f32( &prices[ ( i + 1 ) << 2 ] ), 1,3,5,7 ) );
            }
        }

        if ( messagelength - index2 <= matrixheight ) colmask >>= 1;

        {
            register float32x4_t fillval = vdupq_n_f32( inf );
            for ( l >>= 2; l < sseheight; l++ ) {
                vst1q_f32( &prices[ l << 2 ], fillval );
            }
        }
    }

    totalprice = prices[ 0 ];

    aligned_free( prices );
    free( ssedone );

    if ( totalprice >= total ) {
        free( matrices );
        free( widths );
        free( columns[ 0 ] );
        free( columns[ 1 ] );
        if ( stego != NULL ) free( path );
        throw stc_exception( "No solution exist.", 4 );
    }

    if ( stego != NULL ) {
        pathindex -= parts;
        index--;
        index2--;
        state = 0;

        // unused
        // int h = messagelength;
        state = 0;
        colmask = 0;
        for ( ; index2 >= 0; index2-- ) {
            for ( k = widths[ index2 ] - 1; k >= 0; k--, index-- ) {
                if ( k == widths[ index2 ] - 1 ) {
                    state = ( state << 1 ) + message[ index2 ];
                    if ( messagelength - index2 <= matrixheight ) colmask = ( colmask << 1 ) | 1;
                }

                if ( path[ pathindex + ( state >> 5 ) ] & ( 1 << ( state & 31 ) ) ) {
                    stego[ index ] = 1;
                    state = state ^ ( columns[ matrices[ index2 ] ][ k ] & colmask );
                } else {
                    stego[ index ] = 0;
                }

                pathindex -= parts;
            }
        }
        free( path );
    }

    free( matrices );
    free( widths );
    free( columns[ 0 ] );
    free( columns[ 1 ] );

    return totalprice;
}





void stc_thread( int threadIdx, const thread_info &info, const embed_info &em_info )
{
    // 一共将图像分成info.sections段进行嵌入，开了info.threads个线程，每个线程跑第i,(i+info.threads*1),(i+info.threads*2)...段

    // 开始时间
    timeval start, end;
    gettimeofday(&start, NULL);

    for ( int i = threadIdx; i < info.sections; i += info.threads ) {
        int cover_sec_len = info.cover_section_length;
        int msg_sec_len = info.msg_section_length;

        const char *cover_sec = em_info.cover + i * info.cover_section_length;
        const char *msg_sec = em_info.message + i * info.msg_section_length;
        const float *cost_sec = em_info.costs + i * info.cover_section_length;
        char *stego_sec = em_info.stego + i * info.cover_section_length;

        //用于判断是否最后一段，如果最后一段则嵌入载体长度和嵌入信息并不能保证和前面大小相等，因此需要对载体长度和消息长度
        // 进行重新计算
        bool debug = false;
        if ( ( i + 1 )* info.cover_section_length > em_info.coverlength ) {
            cover_sec_len = em_info.coverlength - i * info.cover_section_length;
        }

        if ( ( i + 1 ) * info.msg_section_length > em_info.messagelength ) {
            debug = true;
            msg_sec_len = em_info.messagelength - i * info.msg_section_length;
        }

        if ( cover_sec_len <= 0 || msg_sec_len <= 0 ) {
            continue;
        }

        stc_embed_inner( cover_sec, cover_sec_len, (const unsigned char *)msg_sec, msg_sec_len, cost_sec, stego_sec, em_info.matrixheight, debug );
    }
    // 结束时间
    gettimeofday(&end, NULL);
    int ttt = 1000*(end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec)/1000;
}

//stc_embed(valid_cover_lsb_noheader, valid_size - 26, messagebit,message_bit_length, valid_cover_cost_noheader,stego_lsb_noheader, 7);
double stc_embed( const char *cover, int coverlength, const char *message, int messagelength, const float *costs, char *stego, int matrixheight ) {

    int sections = 0;
    int cover_sec = 0;
    int msg_sec = 0;
    //分段
    section_policy(coverlength, messagelength, matrixheight, sections, cover_sec, msg_sec );
    //线程数
    int threads = ( 8 > sections ) ? sections : 8;   //最多8个
//    int threads = 1;

    thread_info info;
    info.threads = threads;
    info.sections = sections;
    info.cover_section_length = cover_sec;  //每段的cover的长度
    info.msg_section_length = msg_sec;      //每段的message的长度

    embed_info em_info;
    em_info.cover = cover;
    em_info.coverlength = coverlength;
    em_info.message = message;
    em_info.messagelength = messagelength;
    em_info.costs = costs;
    em_info.stego = stego;
    em_info.matrixheight = matrixheight;

//    for(int i = 0; i<threads; ++i)
//     {
//         stc_thread(i,info,em_info);
//     }

    std::thread *total_threads = new std::thread[threads];
    for(int i = 0; i<threads; ++i)
     {
         total_threads[i] = std::thread(&stc_thread, i,info,em_info);
     }
    for(int i = 0;i<threads;++i)
    {
        //The function returns when the thread execution has completed.
        total_threads[i].join();
    }
    std::this_thread::sleep_for(std::chrono::seconds(1));
    delete[] total_threads;
    return 0.0;
}