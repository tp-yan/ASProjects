#ifndef __JU_COST_MODEL_H__
#define __JU_COST_MODEL_H__

#include <vector>

#include "../cpp/img_jpeg.h"
#include "../cpp/mat2D.h"
#include "wavelets.h"
using namespace std;

class ju_cost_model{
public:
	ju_cost_model (img_jpeg* img_jpeg_ptr,float * valid_cover_cost,int flag);
	~ju_cost_model();

public:
    void    calCosts();

private:
	int		padsize;
	float	sigma;
	int cover_size;
	float * costs;
	img_jpeg* coverStruct;
	int*  index;
	vector<int> randIndex;
	int flag;

private:
	mat2D<double> *lpdf;
	mat2D<double> *hpdf;
	mat2D<double> *Tlpdf;
	mat2D<double> *Thpdf;

	mat2D<mat2D<double> *> *LHwaveletImpact;
	mat2D<mat2D<double> *> *HLwaveletImpact;
	mat2D<mat2D<double> *> *HHwaveletImpact;

	mat2D<double> *R_LH;
	mat2D<double> *R_HL;
	mat2D<double> *R_HH;

private:
	// ���� �˲���
	void	set_filters ( waveletEnum wavelet );
	// ��� JPEG ϵ����С��Ӱ��
	void	calWaveletImpacts ();
	// ���� ����ͼ���С���в�
	void	calCoverResiduals ();
//	void	calCoverResidualsGPU();
	double	alpha ( int coord );
	void	cost_kernel ( int threadIdx, int threads );
};
#endif