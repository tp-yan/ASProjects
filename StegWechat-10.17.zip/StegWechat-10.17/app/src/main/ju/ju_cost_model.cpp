#include "ju_cost_model.h"

#include <algorithm>
#include <limits>
#include <math.h>
#include <random>
#include <iostream>
#include <time.h>
#include <vector>
#include "../cpp/mat2D.h"
#include <thread>
#include <vector>
#include <malloc.h>

using namespace std;

const float wetCost = 1.0e10f;


ju_cost_model::ju_cost_model(img_jpeg* img_jpeg_ptr,float * valid_cover_cost,int flag){
    this->sigma = 0.0156;
	this->cover_size= img_jpeg_ptr->getSize();
	this->costs = valid_cover_cost;
	this->coverStruct = img_jpeg_ptr;
//	this->index = this->coverStruct->getValidCoverIndex().data();
	this->randIndex = this->coverStruct->getValidCoverIndex();
	this->flag = flag;
	this->calCosts ();
}

ju_cost_model::~ju_cost_model ( ) {

	for ( int row = 0; row<8; row++ ) {
		for ( int col = 0; col<8; col++ ) {
			if(flag == 2){
				delete this->LHwaveletImpact->Read ( row, col );
				delete this->HLwaveletImpact->Read ( row, col );
			}
			delete this->HHwaveletImpact->Read ( row, col );
		}
	}
	delete this->HHwaveletImpact;
	if(flag == 2){
		delete this->LHwaveletImpact;
		delete this->HLwaveletImpact;
	}


	delete this->R_HH;
	if(flag == 2){
		delete this->R_HL;
		delete this->R_LH;
	}

	delete this->lpdf;
	delete this->hpdf;
	delete this->Tlpdf;
	delete this->Thpdf;
}


void ju_cost_model::calCosts() {


	this->set_filters( waveletEnum::daubechies8 );

	this->calWaveletImpacts();

//	this->calCoverResidualsGPU();
	this->calCoverResiduals();


 	int threadNums = 8;
	std::thread * threads = new std::thread[threadNums];
	for(int threadId = 0;threadId < threadNums;threadId++){
		threads[threadId] =std::thread(&ju_cost_model::cost_kernel,this,threadId, threadNums);
	}
	for(int threadId = 0;threadId < threadNums;threadId++){
		threads[threadId].join();
	}

	delete[] threads;

}

void ju_cost_model::set_filters ( waveletEnum wavelet ) {
	std::pair<mat2D<double> *, mat2D<double> *> filters = Wavelets::GetWavelets ( wavelet );
	this->lpdf = filters.first;
	this->hpdf = filters.second;
	this->Tlpdf = mat2D<double>::Transpose ( this->lpdf );
	this->Thpdf = mat2D<double>::Transpose ( this->hpdf );

	if ( this->lpdf->cols > this->hpdf->cols ) {
		this->padsize = this->lpdf->cols;
	} else {
		this->padsize = this->hpdf->cols;
	}
}


void ju_cost_model::calWaveletImpacts () {
	// spatial impact of an embedding change in DCT domain (with quantization 1)
	double PI = 3.14159265358979323846;

    mat2D<mat2D<double> *> * spatialImpact = new mat2D<mat2D<double> *>( 8, 8 );
	for ( int u = 0; u < 8; ++u ) {
		for ( int v = 0; v < 8; ++v ) {
			mat2D<double> * idctMat = new mat2D<double> ( 8, 8 );
			for ( int x = 0; x < 8; ++x ) {
				for ( int y = 0; y < 8; ++y ) {
					idctMat->Write ( x, y, alpha ( u ) * alpha ( v ) * cos ( ( PI / 8 )*( x + 0.5 )*u )*cos ( ( PI / 8 )*( y + 0.5 )*v ) );
				}
			}
			spatialImpact->Write ( u, v, idctMat );
		}
	}

	mat2D<double>	*tmp = NULL;
	// wavelet impact of an embedding change in DCT domain (with quantization 1)
	if(flag == 2){
		this->LHwaveletImpact = new mat2D<mat2D<double> *> ( 8, 8 );
		this->HLwaveletImpact = new mat2D<mat2D<double> *> ( 8, 8 );
	}
	this->HHwaveletImpact = new mat2D<mat2D<double> *> ( 8, 8 );
	for ( int row = 0; row < 8; ++row ) {
		for ( int col = 0; col < 8; ++col ) {
			int quant = (coverStruct->quant_tables)[ 0 ]->Read ( row, col );

			mat2D<double>	*t2 =  mat2D<double>::Correlation_Full(spatialImpact->Read ( row, col ),this->Thpdf);
			this->HHwaveletImpact->Write ( row, col, mat2D<double>::Correlation_Full_Last(t2,this->hpdf,quant) );

			if(flag == 2){
				mat2D<double>	*t1 = mat2D<double>::Correlation_Full(spatialImpact->Read ( row, col ),this->Tlpdf);
				this->LHwaveletImpact->Write ( row, col, mat2D<double>::Correlation_Full_Last(t1,this->hpdf,quant) );
				this->HLwaveletImpact->Write ( row, col, mat2D<double>::Correlation_Full_Last(t2,this->lpdf,quant) );
				delete t1;
			}

			delete t2;
		}
	}

	for ( int u = 0; u < 8; ++u ) {
		for ( int v = 0; v < 8; ++v ) {
			delete spatialImpact->Read ( u, v );
		}
	}
	delete spatialImpact;
}


void ju_cost_model::calCoverResiduals () {
	mat2D<int> * spatialCover = (coverStruct->spatial_arrays)[ 0 ];

	mat2D<double>* spatialCover_padded_double = mat2D<int>::Padding_Mirror_Double(spatialCover,this->padsize,this->padsize);

	mat2D<double> * t2= mat2D<double>::Correlation_Same(spatialCover_padded_double,this->Thpdf);
	this->R_HH = mat2D<double>::Correlation_Same_Last(t2,this->hpdf);

	if(flag == 2){
		mat2D<double> * t1= mat2D<double>::Correlation_Same(spatialCover_padded_double,this->Tlpdf);
		this->R_LH = mat2D<double>::Correlation_Same_Last(t1,this->hpdf);
		this->R_HL = mat2D<double>::Correlation_Same_Last(t2,this->lpdf);
		delete t1;
	}

	delete t2;
	delete spatialCover_padded_double;
}

/// <summary>
/// 
/// </summary>
/// <param name="threadIdx"></param>
/// <param name="threads"></param>
void ju_cost_model::cost_kernel( int threadIdx, int threads ) {

    for ( int i = threadIdx; i < this->cover_size; i += threads ) {
//        int row = index[i] / this->coverStruct->image_width;
//        int col = index[i] % this->coverStruct->image_width;
		int row = randIndex[i]/ this->coverStruct->image_width;
		int col = randIndex[i] % this->coverStruct->image_width;

        int modRow = row % 8;
		int modCol = col % 8;

        int subRowsFrom = row - modRow - 6 + this->padsize;
        int subColsFrom = col - modCol - 6 + this->padsize;

        double rho = 0;
        for ( int r_sub = 0; r_sub < 7 + this->padsize; ++r_sub ) {
            for ( int c_sub = 0; c_sub < 7 + this->padsize; ++c_sub ) {
				if(flag == 2){
					rho += LHwaveletImpact->Read( modRow, modCol )->Read( r_sub, c_sub ) / ( R_LH->Read( subRowsFrom + r_sub, subColsFrom + c_sub ) + this->sigma );
					rho += HLwaveletImpact->Read( modRow, modCol )->Read( r_sub, c_sub ) / ( R_HL->Read( subRowsFrom + r_sub, subColsFrom + c_sub ) + this->sigma );
				}
				rho += HHwaveletImpact->Read( modRow, modCol )->Read( r_sub, c_sub ) / ( R_HH->Read( subRowsFrom + r_sub, subColsFrom + c_sub ) + this->sigma );
			}
        }

        if ( rho > wetCost ) {
            rho = wetCost;
        }
		costs[i] = rho;
	   }
}



/// <summary>
/// 
/// </summary>
/// <param name="coord"></param>
/// <returns></returns>
double ju_cost_model::alpha ( int coord ) {
	if ( coord == 0 ) {
		return sqrt ( 1.0 / 8 );
	} else {
		return sqrt ( 2.0 / 8 );
	}
}